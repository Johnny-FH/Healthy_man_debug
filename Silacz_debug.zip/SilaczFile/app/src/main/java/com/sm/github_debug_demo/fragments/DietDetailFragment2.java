package com.sm.github_debug_demo.fragments;


import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Products;
import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.activity.DietActivity;


public class DietDetailFragment2 extends Fragment {

    private int Id;
    private int Diet1;


    private FirebaseDatabase firebaseDatabase;

    private String ProductsList;
    private String name;

    private TextView nameView;
    private String langOption;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (getString(R.string.language).equals(getString(R.string.language_code_pl)))
        {
            langOption = getString(R.string.diet_path);
        }
        else
        {
            langOption = getString(R.string.diet_eng_path);
        }

        View layout = inflater.inflate(R.layout.fragment_diet_detail2, container, false);

        nameView = (TextView) layout.findViewById(R.id.name);
        Button productsView = (Button) layout.findViewById(R.id.producsList);

        productsView.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(getContext(), R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.letter_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setBackgroundResource(R.drawable.letter);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        productsView.setOnClickListener(v -> showList());

        firebaseDatabase = FirebaseDatabase.getInstance();

        if (savedInstanceState != null)
        {
            Diet1 = savedInstanceState.getInt("diet1");
            Id = savedInstanceState.getInt("id");
        }
        else
        {
            DietActivity activity = (DietActivity) getActivity();
            if (activity != null) {
                Id = activity.getDietId();
                Diet1 = activity.getDiet1();
            }
        }


        LoadDiet();


        return layout;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("diet1", Diet1);
        savedInstanceState.putInt("id", Id);
    }

    private void showList()
    {
        if (getContext() == null) return;

        AlertDialog.Builder alert = new AlertDialog.Builder(requireContext());

        final EditText edittext = new EditText(getContext());
        edittext.setInputType(3);
        alert.setMessage(ProductsList);
        alert.setTitle(getString(R.string.products));



        alert.setPositiveButton(getString(R.string.returnn), (dialog, whichButton) -> {


        });


        AlertDialog dialog = alert.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        }
        dialog.show();
    }
    private void LoadDiet()
    {
        String dietType = (Diet1 == 1) ? getString(R.string.reduction_path) : getString(R.string.mass_path);
        int dayNum = (Id % 7) + 1;
        String dayKey = getString(R.string.day_prefix) + dayNum;
        String mealKey = getString(R.string.meal_prefix) + "2";

        firebaseDatabase.getReference().child(langOption).child(dietType).child(dayKey).child(mealKey).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Products products = dataSnapshot.getValue(Products.class);
                    if (products != null) {
                        ProductsList = products.products;
                        name = products.name;
                        nameView.setText(name);
                    }
                } else {
                    if (getContext() != null) {
                        Toast.makeText(getContext(), getString(R.string.db_problem), Toast.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

}