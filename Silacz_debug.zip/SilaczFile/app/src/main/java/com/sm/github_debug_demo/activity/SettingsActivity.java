package com.sm.github_debug_demo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Spinner;

import android.widget.Toast;


import com.github.mikephil.charting.data.Entry;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;

public class SettingsActivity extends AppCompatActivity  {


    private double Water1;
    private FirebaseDatabase firebaseDatabase;

    private String id;
    private String userName;

    private  double Weight;
    private  double Height;
    private int Age;
    private String Gender;


    private double Kcal1;
    private double Kcal2;

    private double BMI;

    private int Diet1;
    private int Training1;
    private int GenderInt;
    private int Connected;
    private int Connection;
    private int newDay;
    private double newWeight;
    private boolean NewWeightBoolean;
    private NumberPicker numberPickerAge;
    private NumberPicker numberPickerHeight;
    private Button buttonEditWeight;
    private int HeightInt;
    private double WaterMax;

    Spinner spinnerTraining;

    Spinner spinnerDiet;

    Spinner spinnerGender;

    ArrayList<Entry> dataVals;


    @SuppressLint({"ClickableViewAccessibility", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        firebaseDatabase = FirebaseDatabase.getInstance();

        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        dataVals = new ArrayList<>();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            getNameAndId();
            ReadOrInitFromFirebase1();

        }

        spinnerTraining = (Spinner) findViewById(R.id.trainingList);
        spinnerTraining.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position)
                {
                    case 0:
                        break;
                    case 1:
                        Training1 = 1;
                        break;
                    case 2:
                        Training1 = 2;
                        break;
                    case 3:
                        Training1 = 3;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerDiet = (Spinner) findViewById(R.id.dietList);
        spinnerDiet.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position)
                {
                    case 0:
                        break;
                    case 1:
                        Diet1 = 1;
                        break;
                    case 2:
                        Diet1 = 2;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinnerGender = (Spinner) findViewById(R.id.genderList);
        spinnerGender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position)
                {
                    case 0:
                        break;
                    case 1:
                        GenderInt = 1;
                        break;
                    case 2:
                        GenderInt = 2;
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        numberPickerAge = (NumberPicker) findViewById(R.id.numberPickerAge);
        numberPickerHeight = (NumberPicker) findViewById(R.id.numberPickerHeight);
        buttonEditWeight = (Button) findViewById(R.id.buttonEditWeight);

        numberPickerAge.setOnValueChangedListener((picker, oldVal, newVal) -> Age = newVal);
        numberPickerHeight.setOnValueChangedListener((picker, oldVal, newVal) -> HeightInt = newVal);

        buttonEditWeight.setOnClickListener(v -> kgAlertSettings());


        Button settingButton = findViewById(R.id.settingButton);

        buttonEditWeight.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        settingButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        settingButton.setOnClickListener(view -> {
            SaveInFirebase();

            Toast.makeText(SettingsActivity.this, getString(R.string.confirmchanges), Toast.LENGTH_SHORT).show();
        });

    }



    private void ReadOrInitFromFirebase1() {

        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if (dataSnapshot.exists()) {
                        Person newPerson = dataSnapshot.getValue(Person.class);
                        if (newPerson != null) {
                            Connected = newPerson.Connected;
                            Connection = newPerson.Connection;
                            Water1 = newPerson.Water;
                            GenderInt = newPerson.GenderId;
                            BMI = newPerson.BMI;
                            Kcal2 = newPerson.KcalTraining;
                            Kcal1 = newPerson.KcalNormal;
                            Training1 = newPerson.Training;
                            Diet1 = newPerson.Diet;
                            Gender = newPerson.Gender;
                            Age = newPerson.Age;
                            Weight = newPerson.Weight;
                            Height = newPerson.Height;
                            newDay = newPerson.Day;
                            newWeight = newPerson.NewWeight;
                            NewWeightBoolean = newPerson.NewWeightBoolean;
                            dataVals = newPerson.dataVals;
                            WaterMax = newPerson.WaterMax;

                            HeightInt = (int) Height;

                            buttonEditWeight.setText(Weight + getString(R.string.kg_suffix));

                            numberPickerAge.setMinValue(0);
                            numberPickerAge.setMaxValue(99);
                            numberPickerAge.setValue(Age);

                            numberPickerHeight.setMinValue(0);
                            numberPickerHeight.setMaxValue(250);
                            numberPickerHeight.setValue(HeightInt);
                        }


                    }
                    else
                    {
                        Toast.makeText(SettingsActivity.this, getString(R.string.db_problem), Toast.LENGTH_LONG).show();
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(SettingsActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }



    }

    private void getNameAndId()
    {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            id = user.getUid();
            String email = user.getEmail();
            if (email != null) {
                userName = StringUtils.substringBefore(email, "@");
            } else {
                userName = user.getDisplayName() != null ? user.getDisplayName() : getString(R.string.default_user_name);
            }
        }
    }

    private void SaveInFirebase()
    {
        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    Height = HeightInt;
                    newWeight = Weight;

                    if (dataVals != null && !dataVals.isEmpty()) {
                        dataVals.get(dataVals.size() - 1).setY((float) Weight);
                    }

                    BMI = Weight/((Height/100)*(Height/100));
                    BMI = Math.round(BMI*100.0) / 100.0;

                    double BMR = 0;

                    if (GenderInt==1)
                    {
                        BMR = (9.99 * Weight) + (6.25 * Height) - (4.92 * Age) + 5;
                    }
                    else if (GenderInt==2)
                    {
                        BMR = (9.99 * Weight) + (6.25 * Height) - (4.92 * Age) -161;
                    }

                    if (Diet1 ==1)
                    {
                        Kcal1 = BMR*1.2;


                        if (Training1 ==1)
                        {
                            Kcal2 = BMR*1.3;
                        }
                        else if (Training1 ==2)
                        {
                            Kcal2 = BMR*1.35;
                        }
                        else if (Training1 ==3)
                        {
                            Kcal2 = BMR*1.4;
                        }
                    }

                    else  if (Diet1 ==2)
                    {
                        Kcal1 = BMR*1.3;

                        if (Training1 ==1)
                        {
                            Kcal2 = BMR*1.4;
                        }
                        else if (Training1 ==2)
                        {
                            Kcal2 = BMR*1.5;
                        }
                        else if (Training1 ==3)
                        {
                            Kcal2 = BMR*1.6;
                        }
                    }

                    Kcal1 = Math.round(Kcal1*100.0) / 100.0;
                    Kcal2 = Math.round(Kcal2*100.0) / 100.0;


                    WaterMax = Weight*0.035;
                    WaterMax = Math.round(WaterMax*100.0) / 100.0;


                    if (Training1==2)
                    {
                        WaterMax = WaterMax+0.2;
                    }
                    else if (Training1==3)
                    {
                        WaterMax = WaterMax+0.5;
                    }


                    Person person = new Person(userName, id, Weight, Height, Age, Gender, Diet1, Training1, Kcal1, Kcal2, BMI, Connected, Connection, GenderInt, Water1, newDay, newWeight, NewWeightBoolean, WaterMax, dataVals);
                    firebaseDatabase.getReference().child("users").child(id).setValue(person);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(SettingsActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }
    }

    private void kgAlertSettings() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        final EditText edittext = new EditText(this);
        edittext.setInputType(3);
        edittext.setText(String.valueOf(Weight));
        alert.setMessage(getString(R.string.kgalert));
        alert.setTitle(getString(R.string.currentWeightUser));

        alert.setView(edittext);

        alert.setPositiveButton(getString(R.string.continuee), (dialog, whichButton) -> {
            try {
                String val = edittext.getText().toString();
                Weight = Double.parseDouble(val);
                buttonEditWeight.setText(Weight + getString(R.string.kg_suffix));

                MediaPlayer clickAlert = MediaPlayer.create(SettingsActivity.this, R.raw.click);
                if (clickAlert != null) clickAlert.start();
            } catch (Exception e) {
                Toast.makeText(SettingsActivity.this, getString(R.string.badWords), Toast.LENGTH_SHORT).show();
            }
        });

        alert.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = alert.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        }
        dialog.show();
    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert =MediaPlayer.create(SettingsActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }



}
