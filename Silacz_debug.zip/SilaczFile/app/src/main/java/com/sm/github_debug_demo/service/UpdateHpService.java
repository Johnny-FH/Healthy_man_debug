package com.sm.github_debug_demo.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.activity.TrainingActivity;
import com.sm.github_debug_demo.model.Musics;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


/**
 * Created by Thor Odynson on 18.02.2021.
 */
public class UpdateHpService extends Service {

    private Toast toast;
    private Timer timer;
    private TimerTask timerTask;
    private static final String CHANNEL_ID = "2";
    private NotificationManager notificationManager;
    private int[] musicId;
    public static MediaPlayer musicPlayer;
    public static final String ACTION_SONG_CHANGED = "com.sm.healthy_man.ACTION_SONG_CHANGED";
    public static final String EXTRA_SONG_ID = "songId";
    public static final String EXTRA_TRAINING_ID = "trainingId";
    public static final String EXTRA_SONG_URI = "songUri";
    public static final String EXTRA_SONG_TITLE = "songTitle";
    public static final String EXTRA_PLAYLIST_URIS = "playlistUris";
    public static final String EXTRA_PLAYLIST_TITLES = "playlistTitles";
    public static final String EXTRA_SONG_INDEX = "songIndex";

    private int trainingId = 0;
    public static String currentTitle;
    public static ArrayList<String> playlistUris = new ArrayList<>();
    public static ArrayList<String> playlistTitles = new ArrayList<>();
    public static boolean isPaused = false;
    public static boolean running = false;
    public static int songId = 0;

    private class MyTimerTask extends TimerTask {
        @Override
        public void run() {
            if (!isPaused) {
                showNotification();
                if (musicPlayer != null && !musicPlayer.isPlaying()) {
                    musicPlayer.start();
                }
            } else {
                if (musicPlayer != null && musicPlayer.isPlaying()) {
                    musicPlayer.pause();
                }
            }
        }
    }

    private void showToast(String text) {
        if (toast == null) {
            toast = Toast.makeText(this, text, Toast.LENGTH_SHORT);
        } else {
            toast.setText(text);
        }
        toast.show();
    }

    private void writeToLogs(String message) {
        Log.d("HelloServices", message);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        toast = Toast.makeText(this, "", Toast.LENGTH_SHORT);
        timer = new Timer();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.CHANNEL_NEWS);
            String description = getString(R.string.CHANNEL_DESCRIPTION);
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        } else {
            notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        }
        writeToLogs("Called onCreate() method.");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        writeToLogs("Called onStartCommand() method");

        if (intent != null) {
            if (intent.hasExtra(EXTRA_PLAYLIST_TITLES)) {
                playlistTitles = intent.getStringArrayListExtra(EXTRA_PLAYLIST_TITLES);
            }
            if (intent.hasExtra(EXTRA_PLAYLIST_URIS)) {
                playlistUris = intent.getStringArrayListExtra(EXTRA_PLAYLIST_URIS);
            }

            int newSongId = intent.getIntExtra(EXTRA_SONG_ID, songId);
            if (intent.hasExtra(EXTRA_SONG_INDEX)) {
                newSongId = intent.getIntExtra(EXTRA_SONG_INDEX, newSongId);
            }

            // If it's a "sync" call or the same song is already playing, just update metadata if needed
            if (running && songId == newSongId && musicPlayer != null && !intent.hasExtra(EXTRA_SONG_URI)) {
                // Keep playing current
            } else {
                songId = newSongId;
                trainingId = intent.getIntExtra(EXTRA_TRAINING_ID, 0);
                currentTitle = intent.getStringExtra(EXTRA_SONG_TITLE);
                String uriString = intent.getStringExtra(EXTRA_SONG_URI);

                if (playlistTitles != null && !playlistTitles.isEmpty() && songId < playlistTitles.size()) {
                    currentTitle = playlistTitles.get(songId);
                }

                if (playlistUris != null && !playlistUris.isEmpty() && songId < playlistUris.size()) {
                    uriString = playlistUris.get(songId);
                }

                if (musicPlayer != null) {
                    musicPlayer.stop();
                    musicPlayer.release();
                    musicPlayer = null;
                }

                try {
                    if (uriString != null) {
                        musicPlayer = MediaPlayer.create(getApplicationContext(), Uri.parse(uriString));
                    } else if (Musics.musicsList != null && songId < Musics.musicsList.length) {
                        musicId = new int[Musics.musicsList.length];
                        for (int i = 0; i < musicId.length; i++) {
                            musicId[i] = Musics.musicsList[i].getImageId();
                        }
                        musicPlayer = MediaPlayer.create(getApplicationContext(), musicId[songId]);
                        if (currentTitle == null) {
                            currentTitle = Musics.musicsList[songId].getTitle();
                        }
                    }
                } catch (Exception e) {
                    Log.e("UpdateHpService", "Error creating MediaPlayer", e);
                }

                if (musicPlayer != null) {
                    musicPlayer.setOnCompletionListener(mp -> {
                        // Auto next
                        if (playlistUris != null && !playlistUris.isEmpty()) {
                            songId = (songId + 1) % playlistUris.size();
                            startNextSong();
                        }
                    });
                    isPaused = false;
                    musicPlayer.start();
                    sendBroadcast(new Intent(ACTION_SONG_CHANGED));
                }
            }
        }

        if (!running) {
            clearTimerSchedule();
            initTask();
            timer.scheduleAtFixedRate(timerTask, 1000, 1000);
            running = true;
        }

        return START_STICKY;
    }

    private void startNextSong() {
        if (playlistUris != null && songId < playlistUris.size()) {
            String uriString = playlistUris.get(songId);
            currentTitle = playlistTitles.get(songId);
            if (musicPlayer != null) {
                musicPlayer.stop();
                musicPlayer.release();
            }
            musicPlayer = MediaPlayer.create(getApplicationContext(), Uri.parse(uriString));
            if (musicPlayer != null) {
                musicPlayer.setOnCompletionListener(mp -> {
                    songId = (songId + 1) % playlistUris.size();
                    startNextSong();
                });
                musicPlayer.start();
                sendBroadcast(new Intent(ACTION_SONG_CHANGED));
            }
        }
    }

    @Override
    public void onDestroy() {
        writeToLogs("Called onDestroy() method");
        clearTimerSchedule();
        running = false;
        isPaused = false;
        playlistUris.clear();
        playlistTitles.clear();

        if (musicPlayer != null) {
            if (musicPlayer.isPlaying()) {
                musicPlayer.stop();
            }
            musicPlayer.release();
            musicPlayer = null;
        }
        super.onDestroy();
    }

    private void clearTimerSchedule() {
        if (timerTask != null) {
            timerTask.cancel();
            timer.purge();
        }
    }

    private void initTask() {
        timerTask = new MyTimerTask();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void showNotification() {
        if (musicPlayer == null) return;

        RemoteViews collapsedView = new RemoteViews(this.getPackageName(), R.layout.notification_collapsed);

        try {
            final int current = musicPlayer.getCurrentPosition();
            final int duration = musicPlayer.getDuration();
            final String elapsedTime = milisecondsToString(current);
            final String durationStr = milisecondsToString(duration);

            collapsedView.setTextViewText(R.id.text_view_collapsed_1, (songId + 1) + ". " + currentTitle);
            collapsedView.setProgressBar(R.id.mf_progress_bar, duration, current, false);
            collapsedView.setTextViewText(R.id.timeMaxTextqq, durationStr);
            collapsedView.setTextViewText(R.id.timeText, elapsedTime);
        } catch (Exception ignored) {}

        Intent notifyIntent = new Intent(this, TrainingActivity.class);
        notifyIntent.putExtra(TrainingActivity.EXTRA_TRAINING_ID, trainingId);
        notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent notifyPendingIntent = PendingIntent.getActivity(
                this, 0, notifyIntent, PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.music_icon)
                .setCustomContentView(collapsedView)
                .setContentIntent(notifyPendingIntent)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setStyle(new NotificationCompat.DecoratedCustomViewStyle())
                .build();

        if (notificationManager != null) {
            notificationManager.notify(2, notification);
        }
    }

    public String milisecondsToString(int time) {
        int minutes = time / 1000 / 60;
        int seconds = time / 1000 % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}
