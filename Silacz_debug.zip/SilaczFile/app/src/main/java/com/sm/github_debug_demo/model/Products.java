package com.sm.github_debug_demo.model;

public class Products {

    public String name;
    public String products;

    public Products(String name, String products) {
        this.name = name;
        this.products = products;
    }

    public Products() {
    }
}
