package com.sm.github_debug_demo.model;

public class TrainingDayMassEasyENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;

    public static final TrainingDayMassEasyENG[] trainingDayMassEasy =
            {
                    new TrainingDayMassEasyENG("Crunches x5",
                            "Isometric abdominal clash 8 s \n \n Break 30 seconds",
                            "Bicycle 10 s",
                            "Double crunch x5 \n \n Break 30s",
                            "Mountain climber 15 s",
                            "Reverse crunches x5",
                            "Plank 10 s \n \n Pause 30 s",
                            "High stepping 15 s",
                            "10s Isometric Belly Clamp"),
                    new TrainingDayMassEasyENG("Squats x5",
                            "Chair by the wall 10 sec",
                            "Lunge x5 \n \n Break 30 s",
                            "Low jumps x10",
                            "Sumo squats x5",
                            "Squats with jump x5 \n \n Break 30 s",
                            "Pulse squats x5",
                            "Plank with leg lift 10 s",
                            "Side leg lift x5 to the side"),
                    new TrainingDayMassEasyENG("X5 pumps",

                            "Rompers x10",

                            "Circulation of arms 20 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 15 seconds",

                            "X5 shooting pumps",

                            "Push-ups with a stop at the bottom 3 seconds x5 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x5",

                            "Diamond pumps x5",

                            "Dips (on chairs) x5"),
                    new TrainingDayMassEasyENG(" FREE TIME "),
                    new TrainingDayMassEasyENG("Jog in 15 seconds",

                            "Rompers x10",

                            "Sprint in place 15 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x5",

                            "Skiping A 15 seconds",

                            "Skiping C 15 seconds \n \n Break 30 seconds",

                            "Mountain climber vigorously 5 seconds",

                            "Feet together, jump forward and backward x5",

                            "Sprint in 15 seconds"),

                    new TrainingDayMassEasyENG("Sumo squats x5",

                            "Raising the hips x5 \n \n Pause 30 seconds",

                            "Side lunges x5 (one side)",

                            "Back Kick on All Fours x5 right side",

                            "Backward Kicks x5 left side \n \n Break 30 seconds",

                            "Raise the legs while lying on the side x15 right side",

                            "Raising the legs while lying on the side x15 left side"),

                    new TrainingDayMassEasyENG("Straddling, we lean down and try to touch the ground (deepened) x5",

                            "Hurdle sitting with straight right leg 10 seconds",

                            "Hurdle sitting with straight left leg 10 seconds",

                            "Sit down for 15 seconds",

                            "Butterfly 15 seconds",

                            "Slowly shifting weight from left to right x4 times",

                            "Pulling the right knee to the chest 10 seconds",

                            "Pulling the left knee to the chest 10 seconds",

                            "Analogous pull of the heel to the buttock (right leg) x4",

                            "Analogous pull of the heel to the buttock (left leg) x4",

                            "Loose jumps for muscle relaxation x10"),
                    new TrainingDayMassEasyENG("FREE TIME"),
                    new TrainingDayMassEasyENG(
                            "Alternate leg lifting x5 per side",

                            "Bicycle 15 seconds",

                            "Double crunch 10 \n \n 30 seconds break",

                            "Mountain climber 20 seconds",

                            "Reverse crunches x8",

                            "Plank 15 seconds \n \n Break 30 seconds",

                            "High stepping 20 seconds",

                            "Isometric Abdominal Clamp 10 Seconds"),
                    new TrainingDayMassEasyENG("squats x8",

                            "Chair against the wall 10 seconds",

                            "Lunge x5 \n \n Break 30 seconds",

                            "Low jumps x12",

                            "Sumo squats x7",

                            "Squats with jump x7 \n \n Break 30 seconds",

                            "Pulse squats x7",

                            "Plank with lifting legs 10 seconds",

                            "Raising the leg on the side 8 times per side"),


                    new TrainingDayMassEasyENG("Ordinary push-ups x7",

                            "Rompers x12",

                            "Circulation of arms 20 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 15 seconds",

                            "X7 shooting pumps",

                            "Push-ups with a stop at the bottom after 3 seconds x7 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x7",

                            "Diamond pumps x7",

                            "Dips (on chairs) x7"),
                    new TrainingDayMassEasyENG("FREE TIME"),
                    new TrainingDayMassEasyENG("Jumping in the place of 20 seconds",

                            "Rompers x12",

                            "Sprint in place 20 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x7",

                            "Skiping A 20 seconds",

                            "Skiping C 20 seconds",

                            "Break 30 seconds",

                            "Mountain climber vigorously 7 seconds",

                            "Feet together, jump forward and backward x7",

                            "Sprint in 20 seconds"),
                    new TrainingDayMassEasyENG("Sumo squats x7",

                            "Raising the hips x7 \n \n Pause 30 seconds",

                            "Side lunges x7 (one side)",

                            "Back Kick on All Fours x7 right side",

                            "Back kick on all fours x7 left side \n \n Break 30 seconds",

                            "Raise the legs while lying on the side x15 right side",

                            "Raising the legs while lying on the side x15 left side"),
                    new TrainingDayMassEasyENG("We lean forward and try to touch the ground (deepened) x7",

                            "Hurdle sitting with straight right leg 15 seconds",

                            "Hurdle sitting with straight left leg 15 seconds",

                            "Sit down for 15 seconds",

                            "Butterfly 20 seconds",

                            "Slowly shifting weight from left to right x8",

                            "Pulling the right knee to the chest 15 seconds",

                            "Pulling the left knee to the chest 15 seconds",

                            "Analogous pull of the heel to the buttock (right leg) x7",

                            "Analogous pull of the heel to the buttock (left leg) x7",

                            "Loose jumps for muscle relaxation x15"),

                    new TrainingDayMassEasyENG(" FREE TIME "),
                    new TrainingDayMassEasyENG("Crunches x15",

                            "Isometric abdominal clash 15 seconds \n \n Break 30 seconds",

                            "Alternating leg lifting x10 per side",

                            "Bicycle 20 seconds",

                            "Double crunch x15 \n \n 30 seconds break",

                            "Second mountain climber 25 seconds",

                            "Reverse crunches x10",

                            "Plank 20 seconds \n \n Break 30 seconds",

                            "High stepping 25 seconds",

                            "Isometric Abdominal Clamp 15 Seconds"),
                    new TrainingDayMassEasyENG("squats x10",

                            "Chair against the wall 15 seconds",

                            "Lunges x7 \n \n Break 30 seconds",

                            "Low jumps x15",

                            "Sumo squats x10",

                            "Squats with jump x10 \n \n Break 30 seconds",

                            "Pulse squats x10",

                            "Plank with lifting legs 15 seconds",

                            "Raising the leg on the side 10 times per side"),
                    new TrainingDayMassEasyENG("Pumps x10",

                            "Rompers x15",

                            "Arm circulation 25 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 15 seconds",

                            "X10 shooting pumps",

                            "Push-ups with a stop of 3 seconds x10 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x10",

                            "Diamond pumps x10",

                            "Dips (on chairs) x10"),
                    new TrainingDayMassEasyENG("FREE TIME"),

                    new TrainingDayMassEasyENG("Jumping in the place of 25 seconds",

                            "Rompers x15",

                            "Sprint in place 25 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x10",

                            "Skiping A 25 seconds",

                            "Skiping C 25 seconds \n \n Break 30 seconds",

                            "Mountain climber vigorously 10 seconds",

                            "Feet together, jump forward and backward x10",

                            "Sprint in 20 seconds"),
                    new TrainingDayMassEasyENG("Sumo squats x10",

                            "Lifting the hips x10 \n \n Pause 30 seconds",

                            "Side lunges x10 (one side)",

                            "Back Kick on All Fours x10 right side",

                            "Backward kick on all fours x10 left side \n \n Break 30 seconds",

                            "Raise the legs while lying on the side x13 right side",

                            "Raise the legs while lying on the side x13 left side"),
                    new TrainingDayMassEasyENG("We lean forward and try to touch the ground (deepened) x10",

                            "Hurdle sitting with straight right leg 20 seconds",

                            "Hurdle sitting with straight left leg 20 seconds",

                            "Sit down for 20 seconds",

                            "Butterfly 25 seconds",

                            "Slowly shifting weight from left to right x10",

                            "Pulling the right knee to the chest 20 seconds",

                            "Pulling the left knee to the chest 20 seconds",

                            "Analogous heel pull to the buttock (right leg) x10",

                            "Analogous heel pull to the buttock (left leg) x10",

                            "Loose jumps for muscle relaxation x20"),
                    new TrainingDayMassEasyENG("FREE TIME"),
                    new TrainingDayMassEasyENG("Crunches x10",

                            "Isometric abdominal clutch 20 seconds \n \n Break 30 seconds",

                            "Alternating leg lifting x15 per side",

                            "Bicycle 25 seconds",

                            "Double crunch x20 \n \n 30 seconds break",

                            "Mountain climber 30 seconds",

                            "Reverse crunches x15",

                            "Plank 25 seconds \n \n Break 30 seconds",

                            "High stepping 30 seconds",

                            "Isometric Abdominal Clamp 20 Seconds"),

                    new TrainingDayMassEasyENG("10 squats",

                            "A chair against the wall 20 seconds",

                            "10 lunges \n \n 30 seconds break",

                            "15 Low Jumps",

                            "15 Sumo Squats",

                            "15 squats with a jump \n \n Break 30 seconds",

                            "Pulse squats x15",

                            "Plank with lifting legs 20 seconds",

                            "Side leg lift x15 to the side"),
                    new TrainingDayMassEasyENG("Pumps x 15",

                            "Rompers x20",

                            "Arm circulation 25 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 20 seconds",

                            "Shooting pumps x15",

                            "Push-ups with a stop 3 seconds x20 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x15",

                            "Diamond pumps x15",

                            "Dips (on chairs) x15"),
                    new TrainingDayMassEasyENG("FREE TIME"),
                    new TrainingDayMassEasyENG("Jog in 30 seconds",

                            "Rompers x20",

                            "Sprint in 30 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x15 times",

                            "Skiping A 30 seconds",

                            "Skiping C 30 seconds \n \n Break 30 seconds",

                            "Mountain climber vigorously 15 seconds",

                            "Feet joined and jump forward and back 15 times",

                            "Sprint in 25 seconds"),
                    new TrainingDayMassEasyENG("Sumo squats x15",

                            "Raising the hips x15 \n \n Pause 30 seconds",

                            "Side lunges x15 (one side)",

                            "Back Kick on All Fours x15 right side",

                            "Backward kick on all fours x15 left side \n \n Break 30 seconds",

                            "Raise the legs while lying on the side x15 right side",

                            "Raising the legs while lying on the side x15 left side"),
            };

    public TrainingDayMassEasyENG() {
    }

    public TrainingDayMassEasyENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }

    public TrainingDayMassEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;



    } // cons

    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    }

    public String getTraining11() {
        return training11;
    }

    public static TrainingDayMassEasyENG[] getTrainingDayMassEasy() {
        return trainingDayMassEasy;
    }// gett
}
