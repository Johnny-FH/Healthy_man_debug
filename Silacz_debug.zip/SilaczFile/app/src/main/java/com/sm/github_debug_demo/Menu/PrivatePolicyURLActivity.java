package com.sm.github_debug_demo.Menu;

import android.media.SoundPool;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.sm.github_debug_demo.R;


public class PrivatePolicyURLActivity extends AppCompatActivity {


    private SoundPool soundPool;
    private int clickSoundId;

    private AdView mAdView;
    protected String privatePolicy;

    TextView privatePolicyTextView, contactTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_policy_u_r_l);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        privatePolicy = getString(R.string.private_policy_detailed);
        privatePolicyTextView = (TextView) findViewById(R.id.policy);
        privatePolicyTextView.setText(privatePolicy);

    }
}
