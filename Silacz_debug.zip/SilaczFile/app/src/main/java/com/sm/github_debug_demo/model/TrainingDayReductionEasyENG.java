package com.sm.github_debug_demo.model;

public class TrainingDayReductionEasyENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;


    public static final TrainingDayReductionEasyENG[] trainingDayReductionEasy =
            {
                    new TrainingDayReductionEasyENG ("Crunches x5", "Isometric abdominal tense 8s \n \n 30s pause", "Alternate leg lifts x3 per side", "Bike 10s", "Double crunch x5 \n \n 30s pause", "Mountain climber 15s "," Reverse crunches x5 "," Plank 10s \n \n Break 30s "," High stepping 15s "," Isometric abdominal clash 10s "),
                    new TrainingDayReductionEasyENG ("Squats x5", "Chair by the wall 10s", "Lunges x5 \n \n Break 30s", "Low jumps x10", "Sumo squats x5", "Squats with jumps x5 \n \n Break 30s" , "Pulse squats x5", "Plank with leg lifting 10s", "Side lifting x5 per side"),
                    new TrainingDayReductionEasyENG ("Running 2km"),
                    new TrainingDayReductionEasyENG("FREE TIME"),
                    new TrainingDayReductionEasyENG ("Jumping 15s", "Jumping x10", "Sprinting 15s \n \n Break 30s", "Jumping (2 lower then 1 higher) x5", "Skiping A 15s", "Skiping C 15s \n \n Break 30s "," Mountain climber vigorously 5s "," Feet clasped "," jump forward and backward x5 "," Sprint at 15s "),
                    new TrainingDayReductionEasyENG ("Sumo Squats x5", "Hip Raise x5 \n \n Break 30s", "Side Lunges x5 per side", "Backward Kicks x5 per side \n \n Break 30s", "Raise legs in lying on the side x15 on the side "),
                    new TrainingDayReductionEasyENG ("Leaning forward and trying to touch the ground (with a deepening) x5", "Hurdles sitting with straightened right leg 10s", "Hurdles sitting with straight left leg 10s", "Sitting sitting down 15s", "Butterfly 15s", "Slowly shifting weight from left to right x4", "Pulling the right knee to the chest 10s", "Pulling the left knee to the chest 10s", "Analogous pulling the heel to the buttock (right leg) x4", "Pulling the heel analogously to buttock (left leg) x4 "," Loose jumps for muscle relaxation x10 "),
                    new TrainingDayReductionEasyENG("FREE TIME"),
                    new TrainingDayReductionEasyENG ("Crunches x10", "Isometric abdominal tense 10s \n \n 30s pause", "Alternate leg lifts x5 per side", "Bike 15s", "Double crunch x10 \n \n 30s pause", "Mountain climber 20s "," Reverse crunches x8 "," Plank 15s \n \n Break 30s "," High stepping 20s "," Isometric belly 10s "),
                    new TrainingDayReductionEasyENG ("Squats x8", "Chair by the wall 10s", "Lunges x5 \n \n Break 30s", "Low jumps x12", "Sumo squats x7", "Squats with jumps x7 \n \n Break 30s" , "Pulse squats x7", "Plank with leg lifting 10s", "Side lifting x8 per side"),
                    new TrainingDayReductionEasyENG ("Running 2km"),
                    new TrainingDayReductionEasyENG ("SLOW"),
                    new TrainingDayReductionEasyENG ("Jumping 20s", "Jumping x12", "Sprinting 20s \n \n Break 30s", "Jumping (2 lower then 1 higher) x7", "Skiping A 20s", "Skiping C 20s \n \n Break 30s "," Mountain climber vigorously "," 7s "," Feet together "," jump forward and backward x7 "," Sprint at 20s "),
                    new TrainingDayReductionEasyENG ("Sumo Squats x7", "Hip Raise x7 \n \n 30s Break", "Side Lunges x7 per side", "Backward Kicks x7 per side \n \n 30s Break", "Raise the legs in lying on the side x15 on the side "),
                    new TrainingDayReductionEasyENG ("Leaning forward and trying to touch the ground (with deepening) x7", "Hurdles sitting with straightened right leg 15s", "Hurdles sitting with straight left leg 15s", "Sitting downstairs 15s", "Butterfly 20s", "Slowly shifting weight from left to right x8", "Pulling the right knee to the chest 15s", "Pulling the left knee to the chest 15s", "Analogous pulling the heel to the buttock (right leg) x7", "Pulling the heel analogously to buttock (left leg) x7 "," Loose jumps for muscle relaxation x15 "),
                    new TrainingDayReductionEasyENG("FREE TIME"),
                    new TrainingDayReductionEasyENG ("Crunches x15", "Isometric abdominal tense 15s \n \n 30s pause", "Alternate leg lifts x10 per side", "Bike 20s", "Double crunch x15 \n \n 30s pause", "Mountain climber 25s "," Reverse crunches x10 "," Plank 20s \n \n Break 30s "," High stepping 25s "," Isometric abdominal 15s "),
                    new TrainingDayReductionEasyENG ("Squats x10", "Chair against the wall 15s", "Lunges x7 \n \n Break 30s", "Low jumps x15", "Sumo squats x10", "Squats with jumps x10 \n \n Break 30s" , "Pulse squats x10", "Plank with leg lifting 15s", "Side lifting x10 per side"),
                    new TrainingDayReductionEasyENG("Running 2km "),
                    new TrainingDayReductionEasyENG("FREE DAY"),
                    new TrainingDayReductionEasyENG ("Jumping 25s", "Jumping x15", "Sprinting 25s \n \n Break 30s", "Jumping (2 lower then 1 higher) x10", "Skiping A 25s", "Skiping C 25s \n \n Break 30s "," Mountain climber vigorously 10s "," Feet clasped "," forward and backward x10 "," Sprint in 20s "),
                    new TrainingDayReductionEasyENG ("Sumo squats x10", "Hip lift x10 \n \n Break 30s", "Side lunges x10 per side", "Backward kicks x10 per side  \n \n Break 30s", "Raise legs in lying on the side x18 on the side "),
                    new TrainingDayReductionEasyENG ("Leaning forward and trying to touch the ground (with a deepening) x10", "Hurdles sitting with straightened right leg 20s", "Hurdles sitting with straight left leg 20s", "Sitting sitting down 20s", "Butterfly 25s", "Slowly shifting weight from left to right x10", "Pulling the right knee to the chest 20s", "Pulling the left knee to the chest 20s", "Analogous pulling the heel to the buttock (right leg) x10", "Pulling the heel analogously to buttock (left leg) x10 "," Loose jumps for muscle relaxation x20 "),
                    new TrainingDayReductionEasyENG("FREE DAY"),
                    new TrainingDayReductionEasyENG ("Crunches x10", "Isometric abdominal tense 20s \n \n 30s pause", "Alternate leg lifts x15 per side", "Bicycles 25s", "Double crunch x20 \n \n 30s pause", "Mountain climber 30s "," Reverse crunches x15 "," Plank 25s \n \n Break 30s "," High stepping 30s "," Isometric abdominal 20s "),
                    new TrainingDayReductionEasyENG ("Squats x10", "Chair against the wall 20s", "Lunges x10 \n \n Break 30s", "Low jumps x15", "Sumo squats x15", "Squats with jumps x15 \n \n Break 30s" , "Pulse squats x15", "Plank with leg lifting 20s", "Side lifting x15 per side"),
                    new TrainingDayReductionEasyENG("Running 2km "),
                    new TrainingDayReductionEasyENG("FREE DAY"),
                    new TrainingDayReductionEasyENG ("Jumping 30s", "Jumping x20", "Sprinting 30s \n \n Break 30s", "Jumping (2 lower then 1 higher) x15", "Skiping A 30s", "Skiping C 30s \n \n Break 30s "," Mountain climber vigorously 15s "," Feet clasped "," forward and backward x15 "," Sprint 25s "),
                    new TrainingDayReductionEasyENG ("Sumo squats x15", "Hip lift x15 \n \n Break 30s", "Side lunges x15 per side", "Backward kicks x15 per side \n \n Break 30s", "Raise legs in lying on the side x18 on the side "),
            };


    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
    }

    public TrainingDayReductionEasyENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }



    public TrainingDayReductionEasyENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayReductionEasyENG() {
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    } // getter

    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining11() {
        return training11;
    }

    public static TrainingDayReductionEasyENG[] getTrainingDayReductionEasy() {
        return trainingDayReductionEasy;
    } // getters



}


