package com.sm.github_debug_demo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;

@SuppressLint("CustomSplashScreen")
public class LoadingActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView loadingText;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Hide title bar and set full screen
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_loading);

        progressBar = findViewById(R.id.progressBar);
        loadingText = findViewById(R.id.loadingText);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();

        startLoadingProcess();

    }





    private void startLoadingProcess() {
        // Initial progress - authorization check
        updateProgress(30, getString(R.string.loading_auth_check));

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String userId = currentUser.getUid();
            updateProgress(60, getString(R.string.loading_profile_fetch));

            // Real loading from Firebase database
            mDatabase.getReference().child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    updateProgress(100, getString(R.string.loading_done));
                    // Short delay to show 100%
                    new Handler().postDelayed(() -> navigateNext(snapshot), 500);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    updateProgress(100, getString(R.string.loading_connection_error));
                    new Handler().postDelayed(() -> {
                        startActivity(new Intent(LoadingActivity.this, MainActivity.class));
                        finish();
                    }, 500);
                }
            });
        } else {
            // User not logged in
            updateProgress(100, getString(R.string.loading_login_required));
            new Handler().postDelayed(() -> {
                startActivity(new Intent(LoadingActivity.this, MainActivity.class));
                finish();
            }, 1000);
        }
    }

    private void updateProgress(int progress, String status) {
        // Smooth progress bar animation
        ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", progressBar.getProgress(), progress);
        animation.setInterpolator(new DecelerateInterpolator());
        animation.start();

        if (loadingText != null) {
            loadingText.setText(status);
        }
    }

    private void navigateNext(DataSnapshot snapshot) {
        if (snapshot.exists()) {
            Person person = snapshot.getValue(Person.class);
            if (person != null && person.Connected == 1) {
                startActivity(new Intent(LoadingActivity.this, MenuActivity.class));
            } else {
                startActivity(new Intent(LoadingActivity.this, StartingPage1.class));
            }
        } else {
            // If user exists in Auth but not in DB
            startActivity(new Intent(LoadingActivity.this, StartingPage1.class));
        }
        finish();
    }
}