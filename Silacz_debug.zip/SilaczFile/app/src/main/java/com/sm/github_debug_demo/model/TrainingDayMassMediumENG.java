package com.sm.github_debug_demo.model;


public class TrainingDayMassMediumENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;
    private String training12;

    public static final TrainingDayMassMediumENG[] trainingDayMassMedium ={

            new TrainingDayMassMediumENG("Crunches x15",

                    "Isometric abdominal clutch 20 seconds \n \n Break 30 seconds",

                    "Alternate leg lifting x5 per side",

                    "Bicycle 30 seconds",

                    "Double crunch x15 \n \n 30 seconds break",

                    "Mountain climber 30 seconds",

                    "Reverse crunches x15",

                    "Plank 30 seconds  \n \n Break 30 seconds",

                    "High stepping 30 seconds",

                    "Isometric Abdominal Clamp 20 Seconds"),
            new TrainingDayMassMediumENG("Squats x20",

                    "Chair against the wall 30 seconds",

                    "Lunge x20 \n \n Break 30 seconds",

                    "Low jumps x20",

                    "Sumo Squats x20",

                    "Squats with jump x10 \n \n Break 30 seconds",

                    "Squats pulse x20",

                    "Plank with lifting legs 30 seconds",

                    "Side leg lift x10 to the side"),
            new TrainingDayMassMediumENG("X20 pumps",

                    "Rompers x20",

                    "Circulation of arms 20 seconds \n \n Break 30 seconds",

                    "Plank with alternating arms forward 30 seconds",

                    "Shooting pumps x15",

                    "Push-ups with a stop at the bottom \n 3 seconds x10 \n \n Break 30 seconds",

                    "Push-ups on the platform \n (e.g. legs on the bed) x10",

                    "Diamond pumps x10",

                    "Dips (on chairs) x20"),
            new TrainingDayMassMediumENG("FREE DAY"),
            new TrainingDayMassMediumENG("Jog in 30 seconds",

                    "Rompers x20",

                    "Sprint in 30 seconds \n \n Break 30 seconds",

                    "Jumps (2 lower then 1 higher) x15",

                    "Skiping A 30 seconds",

                    "Skiping C 30 seconds \n \n Break 30 seconds",

                    "Mountain climber vigorously 15 seconds",

                    "Feet together, jump \n forward and backward x15",

                    "Sprint in 30 seconds"),


            new TrainingDayMassMediumENG(
                    "Sumo Squats x20",

                    "Lifting the hips x20 \n \n Pause 30 seconds",

                    "Side lunges x10 (one side)",

                    "Back Kick on All Fours x15 right side",

                    "Back Kick on All Fours x15 left side",

                    "Raising the legs while lying on the side \n x15 right side",

                    "Raising the legs while lying on the side x15 left side"),
            new TrainingDayMassMediumENG("We lean forward and try to touch the ground (deepened) x10",

                    "Hurdle sitting with straight right leg 30 seconds",

                    "Hurdle sitting with straight left leg 30 seconds \n \n Break 30 seconds",

                    "Sit down wide 30 seconds",

                    "Butterfly 30 seconds",

                    "Slowly shifting weight from left to right x8 times",

                    "Pulling the right knee to the chest 20 seconds \n \n Break 30 seconds",

                    "Pulling the left knee to the chest 20 seconds",

                    "Analogous pull of the heel to the buttock (right leg) x8 times",

                    "Analogous pull of the heel to the buttock (left leg) x8 times",

                    "Loose jumps for muscle relaxation x15"),
            new TrainingDayMassMediumENG("FREE TIME"),
            new TrainingDayMassMediumENG("Crunches x20",

                    "Isometric abdominal clash 25 seconds \n \n Break 30 seconds",

                    "Alternate lifting legs 8 per side",

                    "Bicycle 35 seconds",

                    "Double crunch x20 \n \n 30 seconds break",

                    "Mountain climber 35 seconds",

                    "Reverse crunches x20",

                    "Second plank x35 \n \n Pause 30 seconds",

                    "High stepping 35 seconds",

                    "Isometric Abdominal Clamp 25 Seconds"),
            new TrainingDayMassMediumENG("Squats x25",

                    "A chair against the wall 35 seconds",

                    "Lunges x25  \n \n Break 30 seconds",

                    "Low jumps x25",

                    "Sumo squats x25",

                    "Squats with jump x25 \n \n Break 30 seconds",

                    "Pulse squats x25",

                    "Plank with leg lift 35 seconds",

                    "Side Leg Raise 15 Times Per Side"),


            new TrainingDayMassMediumENG("Ordinary pumps x25",

                    "Rompers x25",

                    "Circulation of arms 20 seconds \n \n Break 30 seconds",

                    "Plank with alternating arms forward 35 seconds",

                    "Shooting pumps x15",

                    "Push-ups with a stop at the bottom after 3 seconds x10 \n \n Break 30 seconds",

                    "Push-ups on a platform (e.g. legs on the bed) x10",

                    "Diamond pumps x12",

                    "Dips (on chairs) x20"),
            new TrainingDayMassMediumENG("WOLNE"),
            new TrainingDayMassMediumENG("place of 40 seconds",

                    "Rompers x25",

                    "Sprint in 30 seconds \n \n Break 30 seconds",

                    "Jumps (2 lower then 1 higher) x15",

                    "Skiping A 35 seconds",

                    "Skiping C 35 seconds \n \n Break 30 seconds",

                    "Mountain climber vigorously 20 seconds",

                    "Feet together, jump forward and backward x20",

                    "Sprint in 30 seconds"),
            new TrainingDayMassMediumENG(
                    "Sumo squats x25",

                    "Raising the hips x25 \n \n Pause 30 seconds",

                    "Side lunges x15 (one side)",

                    "Back Kick on All Fours x20 right side",

                    "Backwards kick on all fours x20 left side \n \n Break 30 seconds",

                    "Raise the legs while lying on the side x15 right side",

                    "Raising the legs while lying on the side x15 left side"),
            new TrainingDayMassMediumENG(
                    "We lean forward and try to touch the ground (deepened) x15",

                    "Hurdle sitting with straight right leg 40 seconds",

                    "Hurdle sitting with straight left leg 40 seconds",

                    "Sit down 40 seconds \n \n Break 30 seconds",

                    "Butterfly 35 seconds",

                    "Slowly shifting weight from left to right x8",

                    "Pulling the right knee to the chest 20 seconds",

                    "Pulling the left knee to the chest 20 seconds \n \n Break 30 seconds",

                    "Analogous pull of the heel to the buttock (right leg) x8",

                    "Analogous pull of the heel to the buttock (left leg) x8",

                    "Loose jumps for muscle relaxation x15"),

            new TrainingDayMassMediumENG("FREE TIME"),
            new TrainingDayMassMediumENG("Crunches x25",

                    "Isometric abdominal clash 30 seconds \n \n Break 30 seconds",

                    "Alternate leg lifting x12 per side",

                    "Bicycle 35 seconds",

                    "25x Double crunch \n \n 30 seconds break",

                    "Second mountain climber 40 seconds",

                    "Reverse crunches x20",

                    "Plank 35 seconds",

                    "Break 30 seconds",

                    "High stepping 35 seconds",

                    "Isometric Abdominal Clamp 25 Seconds"),
            new TrainingDayMassMediumENG("Squats x30",

                    "Chair against the wall 40 seconds",

                    "Lunges x30 \n \n Break 30 seconds",

                    "Low jumps x30",

                    "Sumo squats x30",

                    "Squats with jump x30 \n \n Break 30 seconds",

                    "Pulse squats x30",

                    "Plank with leg lift 35 seconds",

                    "Side Leg Raise 15 Times Per Side"),
            new TrainingDayMassMediumENG("X30 pumps",

                    "Rompers x30",

                    "Arm circulation 25 seconds \n \n Break 30 seconds",

                    "Plank with alternating arms forward 35 seconds",

                    "X25 shooting pumps",

                    "Push-ups with a stop of 3 seconds x15 \n \n Break 30 seconds",

                    "Push-ups on a platform (e.g. legs on the bed) x10",

                    "Diamond pumps x15",

                    "Dips (on chairs) x25"),
            new TrainingDayMassMediumENG("FREE TIME"),


            new TrainingDayMassMediumENG("Jumping in the place of 50 seconds",

                    "Rompers x30",

                    "Sprint in place 35 seconds \n \n Break 30 seconds",

                    "Jumps (2 lower then 1 higher) x20",

                    "Skiping A 35 seconds",

                    "Skiping C 35 seconds \n \n Break 30 seconds",

                    "Mountain climber vigorously 25 seconds",

                    "Feet together, jump forward and backward x20",

                    "Sprint in 35 seconds"),
            new TrainingDayMassMediumENG("Sumo squats x30",

                    "Raising the hips x30 \n \n Pause 30 seconds",

                    "Side lunges x20 (one side)",

                    "Back Kick on All Fours x20 right side",

                    "Backwards kick on all fours x20 left side \n \n Break 30 seconds",

                    "Raising the legs while lying on the side x20 right side",

                    "Raising the legs while lying on the side x20 left side"),
            new TrainingDayMassMediumENG("When we stride, we lean down and try to touch the ground (deepened) x20",

                    "Hurdle sitting with straight right leg 50 seconds",

                    "Hurdle sitting with straight left leg 50 seconds",

                    "Sit down for 50 seconds",

                    "Break 30 seconds",

                    "Butterfly 40 seconds",

                    "Slowly shifting weight from left to right x10",

                    "Pulling the right knee to the chest 25 seconds",

                    "Pulling the left knee to the chest 25 seconds \n \n Break 30 seconds",

                    "Analogous heel pull to the buttock (right leg) x10",

                    "Analogous heel pull to the buttock (left leg) x10",

                    "Loose jumps for muscle relaxation x20"),
            new TrainingDayMassMediumENG("FREE TIME"),
            new TrainingDayMassMediumENG("X30 crunches",

                    "Isometric abdominal clash 35 seconds \n \n Break 30 seconds",

                    "Alternating leg lifting x15 per side",

                    "Bicycle 40 seconds",

                    "Double crunch x25  \n \n 30 seconds break",

                    "Mountain climber 45 seconds",

                    "Reverse crunches x25",

                    "Plank 40 seconds \n \n Break 30 seconds",

                    "High stepping 35 seconds",

                    "Isometric Abdominal Clamp 30 Seconds"),


            new TrainingDayMassMediumENG(
                    "35 squats",

                    "High chair against the wall 45 seconds",

                    "35 lunges \n \n Break 30 seconds",

                    "35 Low Jumps",

                    "35 Sumo squats",

                    "35 jump squats \n \n Break 30 seconds",

                    "Pulse squats x35",

                    "Plank with leg lift 35 seconds",

                    "Side leg lift x30 to the side"),
            new TrainingDayMassMediumENG("Pumps x 35",

                    "Pajacyki 35",

                    "Arm circulation 25 seconds \n \n Break 30 seconds",

                    "Plank with alternating arms forward 35 seconds",

                    "X30 shooting pumps",

                    "Push-ups with a stop 3 seconds x20 \n \n Break 30 seconds",

                    "Push-ups on a platform (e.g. legs on the bed) x15",

                    "Diamond pumps x15",

                    "Dips (on chairs) x30"),
            new TrainingDayMassMediumENG("FREE TIME"),
            new TrainingDayMassMediumENG("Jumping in the place of 50 seconds",

                    "Rompers x30",

                    "Sprint in place 35 seconds \n \n Break 30 seconds",

                    "Jumps (2 lower then 1 higher) 30 times",

                    "Skiping A 35 seconds",

                    "Skiping C 35 seconds \n \n Break 30 seconds",

                    "Mountain climber vigorously 35 seconds",

                    "Feet together and jump forward and back 25 times",

                    "Sprint in 40 Seconds"),
            new TrainingDayMassMediumENG("Sumo squats x40",

                    "Raising the hips x40 \n \n Pause 30 seconds",

                    "Side lunges x25 (one side)",

                    "Back Kick on All Fours x25 right side",

                    "Backward kick on all fours x25 left side \n \n Break 30 seconds",

                    "Raising the legs while lying on the side x25 right side",

                    "Raising the legs while lying on the side x25 left side"),




            };

    public TrainingDayMassMediumENG() {
    }

    public TrainingDayMassMediumENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11, String training12) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
        this.training12 = training12;
    }

    public TrainingDayMassMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;






    } // cons

    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    }

    public String getTraining11() {
        return training11;
    }

    public String getTraining12() {
        return training12;
    }

    public static TrainingDayMassMediumENG[] getTrainingDayMassMedium() {
        return trainingDayMassMedium;
    } // gett
}
