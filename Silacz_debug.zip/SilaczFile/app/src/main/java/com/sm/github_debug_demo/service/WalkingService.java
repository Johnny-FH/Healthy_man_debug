package com.sm.github_debug_demo.service;


import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.activity.WalkingActivity;

import java.util.Locale;

/**
 * WalkingService – foreground service obsługujący śledzenie GPS, stoper
 * oraz powiadomienie na żywo podczas spaceru/biegu.
 *
 * Komunikacja z WalkingActivity odbywa się przez LocalBroadcast:
 *   - Serwis nadaje ACTION_STATE_UPDATE z aktualnym stanem (dystans, czas, prędkość)
 *   - Activity wysyła komendy ACTION_CMD_START / ACTION_CMD_PAUSE / ACTION_CMD_RESET
 */
public class WalkingService extends Service {

    // ── Akcje Intent do sterowania serwisem ──────────────────────────────────
    public static final String ACTION_CMD_START  = "com.sm.healthy_man.walking.START";
    public static final String ACTION_CMD_PAUSE  = "com.sm.healthy_man.walking.PAUSE";
    public static final String ACTION_CMD_RESUME = "com.sm.healthy_man.walking.RESUME";
    public static final String ACTION_CMD_RESET  = "com.sm.healthy_man.walking.RESET";
    public static final String ACTION_CMD_STOP   = "com.sm.healthy_man.walking.STOP";

    // ── Akcja broadcastu stanu wysyłanego do Activity ─────────────────────────
    public static final String ACTION_STATE_UPDATE = "com.sm.healthy_man.walking.STATE_UPDATE";
    public static final String EXTRA_DISTANCE      = "extra_distance";
    public static final String EXTRA_SECONDS       = "extra_seconds";
    public static final String EXTRA_SPEED         = "extra_speed";
    public static final String EXTRA_IS_RUNNING    = "extra_is_running";
    public static final String EXTRA_IS_PAUSED     = "extra_is_paused";

    // ── Notification ──────────────────────────────────────────────────────────
    private static final String CHANNEL_ID      = "walking_channel";
    private static final int    NOTIFICATION_ID = 10;

    // ── Stan śledzenia ────────────────────────────────────────────────────────
    private boolean running  = false;   // stoper / krok-logika aktywna
    private boolean paused   = false;   // czy wstrzymane (p==1)
    private int     p        = 2;       // 0=bieg, 1=pauza, 2=reset (jak w oryginale)
    private int     seconds  = 0;
    private double  distance = 0.0;
    private double  speed    = 0.0;
    private int     kmToText = 1;
    private double  onPause  = 0.0;

    private Location lastLocation;
    private Location lastLocationPause;
    private Location lStart, lEnd, lStartPause, lEndPause;

    // ── GPS ───────────────────────────────────────────────────────────────────
    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationCallback            mLocationCallback;


    public static final String ACTION_CMD_QUERY_STATE = "com.sm.healthy_man.walking.QUERY_STATE";


    // ── Timer ─────────────────────────────────────────────────────────────────
    private Handler timerHandler;
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (running && !paused) {
                seconds++;

                int hours   = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs    = seconds % 60;

                if (distance >= kmToText) {
                    speak(distance, hours, minutes, secs);
                    kmToText++;
                }
            }
            updateNotification();
            broadcastState();
            timerHandler.postDelayed(this, 1000);
        }
    };

    // ── TTS ───────────────────────────────────────────────────────────────────
    private TextToSpeech mTTS;

    // ── Notification ──────────────────────────────────────────────────────────
    private NotificationManager    notificationManager;
    private NotificationCompat.Builder notifBuilder;

    // ─────────────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannel();
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        timerHandler = new Handler();

        mTTS = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = mTTS.setLanguage(Locale.ENGLISH);
                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("WalkingService", "TTS: Language not supported");
                }
            } else {
                Log.e("WalkingService", "TTS: Initialization failed");
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;

        String action = intent.getAction();
        if (action == null) action = "";

        Log.d("WalkingService", "onStartCommand action=" + action);

        switch (action) {
            case ACTION_CMD_START:
                handleStart();
                break;
            case ACTION_CMD_PAUSE:
                handlePause();
                break;
            case ACTION_CMD_RESUME:
                handleResume();
                break;
            case ACTION_CMD_RESET:
                handleReset();
                break;
            case ACTION_CMD_STOP:
                stopSelf();
                break;
            case ACTION_CMD_QUERY_STATE:
                broadcastState(); // serwis od razu odpowiada aktualnym stanem
                break;
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopTracking();
        timerHandler.removeCallbacks(timerRunnable);

        if (mTTS != null) {
            mTTS.stop();
            mTTS.shutdown();
        }

        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // nie używamy bindingu – komunikacja przez broadcast
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Komendy
    // ─────────────────────────────────────────────────────────────────────────

    public static final String EXTRA_ERROR_NO_LOCATION_PERMISSION = "extra_error_no_location_permission";

    private void handleStart() {
        Log.d("WalkingService", "handleStart() called");
        // Na Androidzie 14+ (a zwłaszcza 16) wywołanie startForeground() dla serwisu
        // zadeklarowanego z foregroundServiceType="location" bez przyznanego
        // ACCESS_FINE_LOCATION/ACCESS_COARSE_LOCATION rzuca
        // MissingForegroundServiceTypeException/SecurityException i serwis (a czasem cała
        // aplikacja) ulega restartowi – Activity zostaje wtedy z wiecznym spinnerem,
        // bo nigdy nie przychodzi broadcast z running=true ani błąd.
        // Sprawdzamy to wcześniej i informujemy Activity broadcastem, żeby mogła
        // schować spinner i poprosić o uprawnienia.
        boolean hasLocationPermission =
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        || ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;

        if (!hasLocationPermission) {
            Intent intent = new Intent(ACTION_STATE_UPDATE);
            intent.putExtra(EXTRA_DISTANCE,   distance);
            intent.putExtra(EXTRA_SECONDS,    seconds);
            intent.putExtra(EXTRA_SPEED,      speed);
            intent.putExtra(EXTRA_IS_RUNNING, false);
            intent.putExtra(EXTRA_IS_PAUSED,  false);
            intent.putExtra(EXTRA_ERROR_NO_LOCATION_PERMISSION, true);
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
            return;
        }

        // Reset liczników
        seconds  = 0;
        distance = 0.0;
        speed    = 0.0;
        onPause  = 0.0;
        kmToText = 1;
        lStart = lEnd = lStartPause = lEndPause = null;

        running = true;
        paused  = false;
        p       = 0;

        startForegroundWithNotification();
        startLocationUpdates();
        timerHandler.removeCallbacks(timerRunnable);
        timerHandler.post(timerRunnable);
    }

    private void handlePause() {
        paused  = true;
        running = false;
        p       = 1;
        stopLocationUpdates();
        broadcastState();
    }

    private void handleResume() {
        paused  = false;
        running = true;
        p       = 0;
        startLocationUpdates();
        broadcastState();
    }

    private void handleReset() {
        running  = false;
        paused   = false;
        p        = 2;
        seconds  = 0;
        distance = 0.0;
        speed    = 0.0;
        onPause  = 0.0;
        lStart = lEnd = lStartPause = lEndPause = null;

        stopLocationUpdates();
        timerHandler.removeCallbacks(timerRunnable);
        broadcastState();

        // Serwis możemy zostawić żywy w tle (powiadomienie foreground);
        // zatrzymujemy się dopiero po ACTION_CMD_STOP z Activity
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GPS
    // ─────────────────────────────────────────────────────────────────────────

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        LocationRequest locationRequest = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 2000)
                .setMinUpdateIntervalMillis(1000)
                .build();

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        onNewLocation(location);
                    }
                }
            }
        };

        fusedLocationProviderClient.requestLocationUpdates(
                locationRequest, mLocationCallback, null);
    }

    private void stopLocationUpdates() {
        if (mLocationCallback != null) {
            try {
                fusedLocationProviderClient.removeLocationUpdates(mLocationCallback);
            } catch (Exception ignored) {}
        }
    }

    private void stopTracking() {
        running = false;
        paused  = false;
        stopLocationUpdates();
    }

    private void onNewLocation(Location location) {
        if (p == 0) {
            // Biegniemy
            lastLocation = location;
            if (lStart == null) {
                lStart = lEnd = lastLocation;
            } else {
                lEnd = lastLocation;
            }
            updateKmSpeedInfo();

        } else if (p == 1) {
            // Pauza – mierzymy przesunięcie GPS żeby odjąć je od dystansu
            lastLocationPause = location;
            if (lStartPause == null) {
                lStartPause = lastLocationPause;
            } else {
                lEndPause = lastLocationPause;
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Obliczenia dystansu i prędkości
    // ─────────────────────────────────────────────────────────────────────────

    private void updateKmSpeedInfo() {
        if (lStartPause != null && lEndPause != null) {
            onPause = (lStartPause.distanceTo(lEndPause)) / 1000.0;
        }
        if (lStart != null && lEnd != null) {
            distance = (distance + (lStart.distanceTo(lEnd)) / 1000.0) - onPause;
        }

        if (seconds > 0) {
            speed = (distance * 1000.0) / seconds;
            speed = Math.round(speed * 100.0) / 100.0;
        }

        lStart = lEnd;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Broadcast stanu do Activity
    // ─────────────────────────────────────────────────────────────────────────

    private void broadcastState() {
        Log.d("WalkingService", "broadcastState: running=" + running + " paused=" + paused + " seconds=" + seconds);
        Intent intent = new Intent(ACTION_STATE_UPDATE);
        intent.putExtra(EXTRA_DISTANCE,   distance);
        intent.putExtra(EXTRA_SECONDS,    seconds);
        intent.putExtra(EXTRA_SPEED,      speed);
        intent.putExtra(EXTRA_IS_RUNNING, running);
        intent.putExtra(EXTRA_IS_PAUSED,  paused);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Powiadomienie Foreground
    // ─────────────────────────────────────────────────────────────────────────

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name        = getString(R.string.CHANNEL_NEWS);
            String       description = getString(R.string.CHANNEL_DESCRIPTION);
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, name, NotificationManager.IMPORTANCE_LOW);
            channel.setDescription(description);
            notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        } else {
            notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        }
    }

    private void startForegroundWithNotification() {
        Log.d("WalkingService", "startForegroundWithNotification() calling startForeground()");
        Notification notification = buildNotification();
        try {
            startForeground(NOTIFICATION_ID, notification);
            Log.d("WalkingService", "startForeground() succeeded");
        } catch (Exception e) {
            // Ostatnia linia obrony: jeśli startForeground() z jakiegoś powodu
            // nadal się wywali (np. ForegroundServiceStartNotAllowedException na
            // nowszych Androidach), informujemy Activity, żeby nie zostawiać
            // wiecznego spinnera, i zatrzymujemy próbę startu.
            Log.e("WalkingService", "startForeground() failed", e);
            running = false;
            paused  = false;
            p       = 2;
            stopLocationUpdates();
            timerHandler.removeCallbacks(timerRunnable);

            Intent intent = new Intent(ACTION_STATE_UPDATE);
            intent.putExtra(EXTRA_DISTANCE,   distance);
            intent.putExtra(EXTRA_SECONDS,    seconds);
            intent.putExtra(EXTRA_SPEED,      speed);
            intent.putExtra(EXTRA_IS_RUNNING, false);
            intent.putExtra(EXTRA_IS_PAUSED,  false);
            intent.putExtra(EXTRA_ERROR_NO_LOCATION_PERMISSION, true);
            LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

            stopSelf();
        }
    }

    private Notification buildNotification() {
        int hours   = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs    = seconds % 60;
        String timeStr     = getString(R.string.time_format, hours, minutes, secs);
        String distanceStr = getString(R.string.distance_format, distance);
        String speedStr    = getString(R.string.speed_format, speed);

        // PendingIntent powraca do WalkingActivity po kliknięciu
        Intent activityIntent = new Intent(this, WalkingActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(timeStr)
                .setContentText(distanceStr + "  " + speedStr)
                .setLargeIcon(BitmapFactory.decodeResource(
                        getResources(), R.drawable.ic_icon_large))
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();
    }

    private void updateNotification() {
        if (notificationManager == null) return;
        Notification notification = buildNotification();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, notification);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  TTS
    // ─────────────────────────────────────────────────────────────────────────

    private void speak(double km, int hour, int minutes, int secs) {
        double km1 = Math.round(km * 100.0) / 100.0;

        // Toast wymagałby loopera – używamy kontekstu serwisu (pokazuje się na UI thread)
        new Handler(getMainLooper()).post(() ->
                Toast.makeText(getApplicationContext(),
                        km1 + getString(R.string.km_unit),
                        Toast.LENGTH_SHORT).show());

        if (mTTS == null) return;

        String hourString, minuteString, secsString;

        hourString   = (hour   == 1) ? getString(R.string.hour_one)
                                     : getString(R.string.hours_plural,   hour);
        minuteString = (minutes == 1) ? getString(R.string.minute_one)
                                     : getString(R.string.minutes_plural, minutes);
        secsString   = (secs   == 1) ? getString(R.string.second_one)
                                     : getString(R.string.seconds_plural, secs);

        String kmString = km1 + getString(R.string.kilometers_text);
        String text = getString(R.string.run_prefix) + kmString
                + getString(R.string.time_prefix)
                + hourString + minuteString + secsString;

        mTTS.setSpeechRate(0.5f);
        mTTS.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }
}
