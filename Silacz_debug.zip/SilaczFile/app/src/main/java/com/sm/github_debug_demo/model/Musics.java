package com.sm.github_debug_demo.model;

import androidx.annotation.NonNull;

public class Musics {

    private final int imageId;
    private final String title;


    public static final Musics[] musicsList = {

    };

    public Musics(int imageId, String title) {
        this.imageId = imageId;
        this.title = title;
    }

    public int getImageId() {
        return imageId;
    }

    public String getTitle() {
        return title;
    }



    @NonNull
    @Override
    public String toString() {
        return String.valueOf(imageId);
    }
}
