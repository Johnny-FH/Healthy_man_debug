package com.sm.github_debug_demo.model;

public class TrainingDayReductionMediumENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;

    public static final TrainingDayReductionMediumENG[] trainingDayReductionMedium =
            {

                    new TrainingDayReductionMediumENG ("Crunches x15", "Isometric abdominal tense 15s \n \n 30s pause", "Alternate leg lifts x10 per side", "Bicycles 20s", "Double crunch x15 \n \n 30s pause", "Mountain climber 25s "," Reverse crunches x10 "," Plank 20s \n \n Break 30s "," High stepping 25s "," Isometric abdominal 15s "),
                    new TrainingDayReductionMediumENG ("Squats x20", "Chair against the wall 30s", "Lunges x20 \n \n Break 30s", "Low jumps x20", "Sumo squats x20", "Squats with jumps x10 \n \n Break 30s" , "Pulse squats x20", "Plank with leg lifting 30s", "Side lifting x10 per side"),
                    new TrainingDayReductionMediumENG("Running 5km "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Jumping 30s", "Jumping x20", "Sprinting 30s \n \n Break 30s", "Jumping (2 lower then 1 higher) x15", "Skiping A 30s", "Skiping C 30s \n \n Break 30s "," Mountain climber vigorously 15s "," Feet clasped "," forward and backward x15 "," Sprint 25s "),
                    new TrainingDayReductionMediumENG ("Sumo squats x20", "Hip lift x20 \n \n Break 30s", "Side lunges x10 per side", "Backward kicks x15 per side \n \n Break 30s", "Raise legs in lying on the side x18 on the side "),
                    new TrainingDayReductionMediumENG ("Leaning forward and trying to touch the ground (with a deepening) x10", "Hurdles sitting with straightened right leg 30s", "Hurdles sitting with straight left leg 30s", "Sitting cross-leg 20s", "Butterfly 25s", "Slowly shifting weight from left to right x10", "Pulling the right knee to the chest 20s", "Pulling the left knee to the chest 20s", "Analogous pulling the heel to the buttock (right leg) x10", "Pulling the heel analogously to buttock (left leg) x10 "," Loose jumps for muscle relaxation x20 "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Crunches x20", "Isometric abdominal tense 25s \n \n 30s pause", "Alternate leg lifts x10 per side", "Bikes 35s", "Double crunch x20 \n \n 30s pause", "Mountain climber 35s "," Reverse crunches x20 "," Plank 35s \n \n Break 30s "," High stepping 35s "," Isometric abdominal clash 25s "),
                    new TrainingDayReductionMediumENG ("Squats x25", "Chair against the wall 35s", "Lunges x25 \n \n Break 30s", "Low jumps x25", "Sumo squats x25", "Squats with jumps x15 \n \n Break 30s" , "Pulse squats x25", "Plank with leg lifting 35s", "Side lifting x15 per side"),
                    new TrainingDayReductionMediumENG("Running 5km "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Jumping 40s", "Jumping x25", "Sprinting 30s \n \n Break 30s", "Jumping (2 lower then 1 higher) x15", "Skiping A 35s", "Skiping C 35s \n \n Break 30s "," Mountain climber vigorously 20s "," Feet clasped "," forward and backward x20 "," Sprint in 30s "),
                    new TrainingDayReductionMediumENG ("Sumo squats x25", "Hip lift x25 \n \n Break 30s", "Side lunges x15 per side", "Backward kicks x20 per side \n \n Break 30s", "Raise legs in lying on the side x20 on the side "),
                    new TrainingDayReductionMediumENG ("Leaning forward and trying to touch the ground (with deepening) x15", "Hurdles sit with straightened right leg 40s", "Hurdles sit with straight left leg 40s", "Cross-legged sit 30s", "Butterfly 30s", "Slowly shifting body weight from left to right x15", "Pulling the right knee to the chest 25s", "Pulling the left knee to the chest 25s", "Analogous pulling the heel to the buttock (right leg) x15", "Pulling the heel analogously to buttock (left leg) x15 "," Loose jumps for muscle relaxation x25 "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Crunches x25", "Isometric Abdominal Clamp 30s \n \n Break 30s", "Alternate Leg Raises x12 per side", "Bikes 35s", "Double crunch x25 \n \n Break 30s", "Mountain climber 40s "," Reverse crunches x20 "," Plank 35s \n \n Break 30s "," High stepping 35s "," Isometric abdominal 30s "),
                    new TrainingDayReductionMediumENG ("Squats x30", "Chair against the wall 40s", "Lunges x30 \n \n Break 30s", "Low jumps x30", "Sumo squats x30", "Squats with jumps x20 \n \n Break 30s" , "Pulse squats x30", "Plank with lifting legs 40s", "Side lifting x20 per side"),
                    new TrainingDayReductionMediumENG("Running 5km "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Jumping 50s", "Jumping x30", "Sprinting 35s \n \n Break 30s", "Jumping (2 lower then 1 higher) x20", "Skiping A 40s", "Skiping C 40s \n \n Break 30s "," Mountain climber vigorously 25s "," Feet clasped "," forward and backward x20 "," Sprint 35s "),
                    new TrainingDayReductionMediumENG ("Sumo squats x30", "Hip lift x30 \n \n Break 30s", "Side lunges x20 per side", "Backward kicks x20 per side \n \n Break 30s", "Raise legs in lying on the side x20 on the side "),
                    new TrainingDayReductionMediumENG ("Leaning forward and trying to touch the ground (deepened) x20", "Hurdles sitting with straightened right leg 50s", "Hurdles sitting with straight left leg 50s", "Sitting sitting 40s", "Butterfly 40s", "Slowly shifting body weight from left to right x20", "Pulling the right knee to the chest 25s", "Pulling the left knee to the chest 25s", "Analogous pulling the heel to the buttock (right leg) x15", "Pulling the heel analogously to buttock (left leg) x15 "," Loose jumps for muscle relaxation x25 "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Crunches x30", "Isometric abdominal tense 35s \n \n 30s pause", "Alternate leg lifts x15 per side", "Bicycles 40s", "Double crunch x25 \n \n 30s pause", "Mountain climber 45s "," Reverse crunches x25 "," Plank 40s \n \n 30s break "," High stepping 35s "," Isometric abdominal 30s "),
                    new TrainingDayReductionMediumENG ("Squats x35", "Chair against the wall 45s", "Lunges x35 \n \n Break 30s", "Low jumps x35", "Sumo squats x35", "Squats with jumps x25 \n \n Break 30s" , "Pulse squats x35", "Plank with leg lifting 35s", "Side lifting x30 per side"),
                    new TrainingDayReductionMediumENG("Bieganie 5km "),
                    new TrainingDayReductionMediumENG("FREE TIME"),
                    new TrainingDayReductionMediumENG ("Jumping 50s", "Jumping x30", "Sprinting 35s \n \n Break 30s", "Jumping (2 lower then 1 higher) x20", "Skiping A 40s", "Skiping C 40s \n \n Break 30s "," Mountain climber vigorously 25s "," Feet clasped "," forward and backward x20 "," Sprint 35s "),
                    new TrainingDayReductionMediumENG ("Sumo squats x40", "Hip lift x40 \n \n 30s break", "Side lunges x25 per side", "Backward kicks x25 per side \n \n 30s pause", "Raise legs in lying on the side x25 on the side "),

            };


    public TrainingDayReductionMediumENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayReductionMediumENG() {
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }

    public TrainingDayReductionMediumENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;



    }// cons


    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    }

    public String getTraining11() {
        return training11;
    }

    public static TrainingDayReductionMediumENG[] getTrainingDayReductionMedium() {
        return trainingDayReductionMedium;
    } // gett
}
