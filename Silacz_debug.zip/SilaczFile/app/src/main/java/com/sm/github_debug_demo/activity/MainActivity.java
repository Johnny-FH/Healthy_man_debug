package com.sm.github_debug_demo.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.sm.github_debug_demo.Menu.PrivatePolicyURLActivity;
import com.sm.github_debug_demo.Menu.ProducentsInfoActivity;
import com.github.mikephil.charting.data.Entry;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 9001;
    private static final String TAG = "GoogleActivity";

    private int Connected;
    private String id;
    private String userName;

    private FirebaseDatabase firebaseDatabase;
    private ArrayList<Entry> dataVals;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        dataVals = new ArrayList<>();

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        Button loginGoogle = findViewById(R.id.LoginGoogle);

        loginGoogle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert = MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        loginGoogle.setOnClickListener(view -> signIn());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    firebaseAuthWithGoogle(account.getIdToken());
                }
            } catch (ApiException e) {
                Log.w(TAG, getString(R.string.loading_connection_error), e);
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sign_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        MediaPlayer clickAlert1 = MediaPlayer.create(MainActivity.this, R.raw.click);
        if (clickAlert1 != null) clickAlert1.start();
        
        if (itemId == R.id.private_policy) {
            startActivity(new Intent(MainActivity.this, PrivatePolicyURLActivity.class));
            return true;
        }
        if (itemId == R.id.producents_info) {
            startActivity(new Intent(MainActivity.this, ProducentsInfoActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        getNameAndId();
                        ReadOrInitFromFirebase();
                    }
                });
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityIfNeeded(signInIntent, RC_SIGN_IN);
    }

    private void ReadOrInitFromFirebase() {
        if (id == null) return;
        
        firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Person newPerson = dataSnapshot.getValue(Person.class);
                    if (newPerson != null) {
                        Connected = newPerson.Connected;
                        if (Connected == 1) {
                            startActivity(new Intent(MainActivity.this, MenuActivity.class));
                            finish();
                        } else {
                            startActivity(new Intent(MainActivity.this, StartingPage1.class));
                        }
                    }
                } else {
                    Person person = new Person(userName, id, 0, 0, 0, getString(R.string.lack), 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, false, 0, dataVals);
                    firebaseDatabase.getReference().child("users").child(id).setValue(person);
                    startActivity(new Intent(MainActivity.this, StartingPage1.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e(TAG, getString(R.string.db_error) + " " + databaseError.getMessage());
            }
        });
    }

    private void getNameAndId() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            id = user.getUid();
            String email = user.getEmail();
            if (email != null) {
                userName = StringUtils.substringBefore(email, "@");
            } else {
                userName = user.getDisplayName();
                if (userName == null) userName = getString(R.string.default_user_name);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firebaseAuth.getCurrentUser() != null) {
            getNameAndId();
            ReadOrInitFromFirebase1();
        }
    }

    private void ReadOrInitFromFirebase1() {
        if (id == null) return;
        
        firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Person newPerson = dataSnapshot.getValue(Person.class);
                    if (newPerson != null) {
                        Connected = newPerson.Connected;
                        if (Connected == 1) {
                            startActivity(new Intent(MainActivity.this, MenuActivity.class));
                            finish();
                        } else if (Connected == 0) {
                            firebaseAuth.signOut();
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert = MediaPlayer.create(MainActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }
}