package com.sm.github_debug_demo.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.model.TrainingDayMassMedium;
import com.sm.github_debug_demo.model.TrainingDayMassMediumENG;
import com.sm.github_debug_demo.model.TrainingDayReductionEasy;
import com.sm.github_debug_demo.model.TrainingDayReductionHard;
import com.sm.github_debug_demo.model.TrainingDayReductionMedium;
import com.sm.github_debug_demo.activity.TrainingActivity;


public class TrainingDetailFragment12 extends Fragment {

    private int Id;
    private TextView trainingTextView;


    private int Diet1;
    private int Training1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);





    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View layout = inflater.inflate(R.layout.fragment_training_detail12, container, false);

        trainingTextView = (TextView) layout.findViewById(R.id.trainingDetailText12);


        if (savedInstanceState != null)
        {
            Diet1 = savedInstanceState.getInt("diet1");
            Training1 = savedInstanceState.getInt("training1");
            Id = savedInstanceState.getInt("id");
        }
        else {
            TrainingActivity activity = (TrainingActivity) getActivity();
            assert activity != null;
            Id = activity.trainingId();
            Diet1 = activity.getDiet1();
            Training1 = activity.getTraining1();
        }



        readTraining();
        return layout;


    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        savedInstanceState.putInt("diet1", Diet1);
        savedInstanceState.putInt("training1", Training1);
        savedInstanceState.putInt("id", Id);
    }


    private void readTraining()
    {
        String trainingText;
        if (Diet1 == 2)
        {
            if (getResources().getString(R.string.language).equals("PL"))
            {
                if (Training1==2)
                {

                    trainingText = TrainingDayMassMedium.trainingDayMassMedium[Id].getTraining12();
                    trainingTextView.setText(trainingText);
                }
            }
            else
            {
                if (Training1==2)
                {

                    trainingText = TrainingDayMassMediumENG.trainingDayMassMedium[Id].getTraining12();
                    trainingTextView.setText(trainingText);
                }
            }


        }
        else if (Diet1 ==1)
        {
            if (Training1==1)
            {

                trainingText = TrainingDayReductionEasy.trainingDayReductionEasy[Id].getTraining1();
                trainingTextView.setText(trainingText);
            }
            else if (Training1==2)
            {

                trainingText = TrainingDayReductionMedium.trainingDayReductionMedium[Id].getTraining1();
                trainingTextView.setText(trainingText);
            }
            else if (Training1 ==3)
            {

                trainingText = TrainingDayReductionHard.trainingDayReductionHard[Id].getTraining1();
                trainingTextView.setText(trainingText);
            }
        }

    }
}
