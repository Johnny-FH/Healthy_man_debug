package com.sm.github_debug_demo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.Toast;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.sm.github_debug_demo.data.QuestionsDatabaseHelper;
import com.sm.github_debug_demo.R;

public class StartingPage2 extends AppCompatActivity {


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_page2);



        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        Button trainingamator = findViewById(R.id.Mass_diet);
        Button dietReduction = findViewById(R.id.reduction_diet);

        dietReduction.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.dieta_redukcja_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {

                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    v.setBackgroundResource(R.drawable.dieta_redukcja);
                    break;
                }
            }
            return false;
        });

        trainingamator.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.dieta_moc_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {

                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    v.setBackgroundResource(R.drawable.dieta_moc);
                    break;
                }
            }
            return false;
        });
        trainingamator.setOnClickListener(view -> {
            try {
                SQLiteOpenHelper questionsDatabaseHelper = new QuestionsDatabaseHelper(StartingPage2.this);
                SQLiteDatabase db = questionsDatabaseHelper.getWritableDatabase();

                ContentValues Info1 = new ContentValues();
                Info1.put("DIETA", getString(R.string.muscleMass));

                db.update("INFO1", Info1, "_id = ?", new String[]{Integer.toString(1)});

                ContentValues Info2 = new ContentValues();
                Info2.put("DIET1", 2);

                db.update("INFO1", Info2, "_id = ?", new String[]{Integer.toString(1)});


                db.close();

                Intent intent = new Intent(StartingPage2.this, StartingPage3.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(StartingPage2.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
            }
        });


        dietReduction.setOnClickListener(view -> {
            try {
                SQLiteOpenHelper questionsDatabaseHelper = new QuestionsDatabaseHelper(this);
                SQLiteDatabase db = questionsDatabaseHelper.getWritableDatabase();

                ContentValues Info1 = new ContentValues();
                Info1.put("DIETA", getString(R.string.Reduction));

                db.update("INFO1", Info1, "_id = ?", new String[]{Integer.toString(1)});

                ContentValues Info2 = new ContentValues();
                Info2.put("DIET1", 1);

                db.update("INFO1", Info2, "_id = ?", new String[]{Integer.toString(1)});



                db.close();



                Intent intent = new Intent(StartingPage2.this, StartingPage3.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(StartingPage2.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
            }

        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert =MediaPlayer.create(StartingPage2.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }

}