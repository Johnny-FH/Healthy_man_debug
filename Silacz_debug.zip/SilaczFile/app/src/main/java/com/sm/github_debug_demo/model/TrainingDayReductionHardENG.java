package com.sm.github_debug_demo.model;

public class TrainingDayReductionHardENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;


    public static final TrainingDayReductionHardENG[] trainingDayReductionHard =
            {

                    new TrainingDayReductionHardENG ("Squats x25", "Chair against the wall two sets of 35 seconds", "Lunges x25 \n \n Break 30s", "Low jumps x25", "Sumo squats x25", "Squats with jumps x15 \n \n Break 30s "," Pulse squats x25 "," Plank with leg lifting 35s "," Side lift x15 per side "),
                    new TrainingDayReductionHardENG("Running 10km "),
                    new TrainingDayReductionHardENG("FREE TIME"),
                    new TrainingDayReductionHardENG ("Jumping 40s", "Jumping x25", "Sprinting 30s \n \n Break 30s", "Jumping (2 lower then 1 higher) x15", "Skiping A 35s", "Skiping C 35s \n \n Break 30s "," Mountain climber vigorously 20s "," Feet clasped "," forward and backward x20 "," Sprint in 30s "),
                    new TrainingDayReductionHardENG ("Sumo Squats x25", "Hip Lift x25 \n \n 30s Break", "Side Lunges x15 per side", "Backward Kicks x20 per side \n \n 30s Break", "Raise the legs in lying on the side x20 on the side "),
                    new TrainingDayReductionHardENG ("Leaning forward and trying to touch the ground (with a deepening) x15", "Hurdles sitting with straightened right leg 40s", "Hurdles sitting with straight left leg 40s", "Sitting sitting knees 30s", "Butterfly 30s", "Slowly shifting body weight from left to right x15", "Pulling the right knee to the chest 25s", "Pulling the left knee to the chest 25s", "Analogous pulling the heel to the buttock (right leg) x15", "Pulling the heel analogously to buttock (left leg) x15 "," Loose jumps for muscle relaxation x25 "),
                    new TrainingDayReductionHardENG("FREE TIME"),
                    new TrainingDayReductionHardENG ("Crunches x30", "Isometric Abdominal Clamp 30s \n \n Break 30s", "Alternate Leg Raises x12 per side", "Bike 50s", "Double crunch x25 \n \n Break 30s", "Mountain climber 50s "," Reverse crunches x25 "," Plank 45s \n \n 30s break "," High stepping 50s "," Isometric abdominal 30s "),
                    new TrainingDayReductionHardENG ("Squats x30", "Chair against the wall two sets of 40s", "Lunges x30 \n \n Break 30s", "Low jumps x30", "Sumo squats x30", "Squats with jumps x30 \n \n Break 30s "," Pulse squats x30 "," Plank with lifting legs 40s "," Raising leg on the side x20 per side "),
                    new TrainingDayReductionHardENG("Running 10km "),
                    new TrainingDayReductionHardENG("FREE DAY"),
                    new TrainingDayReductionHardENG ("Jumping 45s", "Jumping x30", "Sprinting 35s \n \n Break 30s", "Jumping (2 lower then 1 higher) x20", "Skiping A 40s", "Skiping C 40s \n \n Break 30s "," Mountain climber vigorously 25s "," Feet clasped "," forward and backward x25 "," Sprint 35s "),
                    new TrainingDayReductionHardENG ("Sumo Squats x30", "Hip Raise x30 \n \n Break 30s", "Side Lunges x20 per side", "Backward Kicks x25 per side \n \n Break 30s", "Raise legs in lying on the side x20 on the side "),
                    new TrainingDayReductionHardENG ("Leaning forward and trying to touch the ground (deepened) x20", "Hurdles sitting with straightened right leg 45s", "Hurdles sitting with straight left leg 45s", "Sitting sitting 45s", "Butterfly 40s", "Slowly shifting body weight from left to right x15", "Pulling the right knee to the chest 25s", "Pulling the left knee to the chest 25s", "Analogous pulling the heel to the buttock (right leg) x15", "Pulling the heel analogously to buttock (left leg) x15 "," Loose jumps for muscle relaxation x25 "),
                    new TrainingDayReductionHardENG("FREE DAY"),
                    new TrainingDayReductionHardENG ("Crunches x35", "Isometric Abdominal Clamp 35s \n \n Break 30s", "Alternate Leg Raises x15 per side", "Bike 55s", "Double crunch x30 \n \n Break 30s", "Mountain climber 55s "," Reverse crunches x30 "," Plank 55s \n \n Break 30s "," High stepping 55s "," Isometric abdominal clamp 35s "),
                    new TrainingDayReductionHardENG ("Squats x35", "Chair against the wall two sets of 45s", "Lunges x35 \n \n Break 30s", "Low jumps x35", "Sumo squats x35", "Squats with jumps x35 \n \n Break 30s "," Pulse squats x35 "," Plank with leg lifting 45s "," Side lift x25 per side "),
                    new TrainingDayReductionHardENG("Running 10km "),
                    new TrainingDayReductionHardENG("FREE DAY"),
                    new TrainingDayReductionHardENG ("Jumping 50s", "Jumping x35", "Sprinting 40s \n \n Break 30s", "Jumping (2 lower then 1 higher) x25", "Skiping A 45s", "Skiping C 45s \n \n Break 30s "," Mountain climber vigorously 30s "," Feet clasped "," forward and backward x30 "," Sprint in 40s "),
                    new TrainingDayReductionHardENG ("Leaning forward and trying to touch the ground (with deepening) x25", "Hurdles sitting with straightened right leg 50s", "Hurdles sitting with straight left leg 50s", "Sitting downstairs 50s", "Butterfly 45s", "Slowly shifting weight from left to right x20", "Pulling the right knee to the chest 30s", "Pulling the left knee to the chest 30s", "Analogous pulling the heel to the buttock (right leg) x20", "Pulling the heel analogously to buttock (left leg) x20 "," Loose jumps for muscle relaxation x30 "),
                    new TrainingDayReductionHardENG("FREE DAY"),
                    new TrainingDayReductionHardENG ("Crunches x40", "Isometric abdominal clutch 40s \n \n 30s pause", "Alternate leg lifts x18 per side", "Bike 60s", "Double crunch x35 \n \n 30s pause", "Mountain climber 60s "," Reverse crunches x35 "," Plank 60s \n \n Break 30s "," High stepping 60s "," Isometric abdominal clash 40s "),
                    new TrainingDayReductionHardENG ("Squats x40", "Chair against the wall two sets of 50s", "Lunges x40 \n \n Break 30s", "Low jumps x40", "Sumo squats x40", "Squats with jumps x40 \n \n Break 30s "," Pulse squats x40 "," Plank with leg lifting 50s "," Side lift x30 per side "),
                    new TrainingDayReductionHardENG("Running 10km "),
                    new TrainingDayReductionHardENG("FREE DAY"),
                    new TrainingDayReductionHardENG ("Jumping 55s", "Jumping x40", "Sprinting 45s \n \n Break 30s", "Jumping (2 lower then 1 higher) x30", "Skiping A 50s", "Skiping C 50s \n \n Break 30s "," Mountain climber vigorously 35s "," Feet clasped "," forward and backward x35 "," Sprint 45s "),
                    new TrainingDayReductionHardENG ("Sumo Squats x40", "Hip Raise x40 \n \n Break 30s", "Side Lunges x30 per side", "Backward Kicks x35 per side  \n \n Break 30s", "Raise legs in lying on the side x30 on the side "),
            };


    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
    }


    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayReductionHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }

    public TrainingDayReductionHardENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayReductionHardENG() {
    }// cons

    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    }

    public String getTraining11() {
        return training11;
    }

    public static TrainingDayReductionHardENG[] getTrainingDayReductionHard() {
        return trainingDayReductionHard;
    } // getters
}



