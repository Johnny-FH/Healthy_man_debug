package com.sm.github_debug_demo.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.sm.github_debug_demo.BuildConfig;
import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.service.WalkingService;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

/**
 * WalkingActivity – warstwa UI.
 * Logika śledzenia GPS, stoper i powiadomienia zostały przeniesione
 * do {@link WalkingService} (foreground service).
 *
 * Komunikacja:
 *   Activity  → Service : startService(intent z akcją ACTION_CMD_*)
 *   Service   → Activity: broadcast ACTION_STATE_UPDATE z Extras
 */
public class WalkingActivity extends AppCompatActivity implements OnMapReadyCallback {

    // ── Widoki ────────────────────────────────────────────────────────────────
    private ProgressBar progressBar;
    private TextView    time, distanceText, speedView;
    private Button      btnPause, btnStart, btnReset, btnMap;
    private Toolbar     toolbar;

    // ── Mapa ──────────────────────────────────────────────────────────────────
    private GoogleMap  map;
    private LatLng     latLng;
    private Marker     markerProfil;
    private MarkerOptions markerOptions;
    private FusedLocationProviderClient fusedLocationProviderClient;

    // ── Stan UI (zsynchronizowany ze stanem serwisu) ──────────────────────────
    private boolean running  = false;
    private boolean paused   = false;
    private int     buttonInt = 0; // 1 = aktywny, 2 = wstrzymany
    private int     p         = 2; // 0=bieg, 1=pauza, 2=reset
    private boolean mapClicked = false;
    private int     i = 0; // licznik back-press

    // ── Dane wyświetlane (otrzymywane z serwisu) ──────────────────────────────
    private double lastDistance = 0.0;
    private int    lastSeconds  = 0;
    private double lastSpeed    = 0.0;



    // ── BroadcastReceiver od serwisu ──────────────────────────────────────────
    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @SuppressLint("DefaultLocale")
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!WalkingService.ACTION_STATE_UPDATE.equals(intent.getAction())) return;

            lastDistance = intent.getDoubleExtra(WalkingService.EXTRA_DISTANCE, 0.0);
            lastSeconds  = intent.getIntExtra(WalkingService.EXTRA_SECONDS,     0);
            lastSpeed    = intent.getDoubleExtra(WalkingService.EXTRA_SPEED,    0.0);
            running      = intent.getBooleanExtra(WalkingService.EXTRA_IS_RUNNING, false);
            paused       = intent.getBooleanExtra(WalkingService.EXTRA_IS_PAUSED,  false);

            Log.d("WalkingActivity", "stateReceiver: running=" + running + " paused=" + paused
                    + " seconds=" + lastSeconds + " errNoLoc="
                    + intent.getBooleanExtra(WalkingService.EXTRA_ERROR_NO_LOCATION_PERMISSION, false)
                    + " progressBarVisible=" + (progressBar.getVisibility() == View.VISIBLE));

            if (intent.getBooleanExtra(WalkingService.EXTRA_ERROR_NO_LOCATION_PERMISSION, false)) {
                // Serwis nie mógł wystartować, bo brak uprawnień lokalizacji
                // (na Androidzie 14+/16 startForeground() dla FGS typu "location"
                // wymaga ich z góry) – chowamy spinner, wracamy do stanu początkowego
                // i dopytujemy o uprawnienia.
                progressBar.setVisibility(View.GONE);
                btnStart.setVisibility(View.VISIBLE);
                btnPause.setVisibility(View.GONE);
                btnReset.setVisibility(View.GONE);
                Toast.makeText(WalkingActivity.this, getString(R.string.permission_denied_toast), Toast.LENGTH_SHORT).show();

                if (ContextCompat.checkSelfPermission(WalkingActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ContextCompat.checkSelfPermission(WalkingActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                    }, 1000);
                }
                return;
            }

            updateUiFromState();
        }
    };

    // ─────────────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    @SuppressLint({"DefaultLocale", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_walking);

        toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        checkGPS();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // UWAGA: wszystkie uprawnienia muszą być poproszone w JEDNYM wywołaniu
        // requestPermissions(). Na Androidzie 16, jeśli wywołamy requestPermissions()
        // dwa razy z rzędu (np. najpierw verifyStoragePermission(), a potem ten blok),
        // system loguje "Can request only one set of permissions at a time" i drugi
        // dialog nigdy się nie pojawia – odpowiadające mu uprawnienia (lokalizacja,
        // notyfikacje) zostają na DENIED, co prowadzi do wiecznego spinnera.
        java.util.ArrayList<String> permsToRequest = new java.util.ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        // Od Androida 13 (TIRAMISU) o to uprawnienie trzeba poprosić wprost,
        // inaczej powiadomienie z foreground service nigdy się nie pojawi
        // i system nie zapyta o nie dopóki nie zrobi tego inny ekran (np. MusicFragment).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permsToRequest.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!permsToRequest.isEmpty()) {
            requestPermissions(permsToRequest.toArray(new String[0]), 1000);
        }

        initViews();
        setupButtonListeners();

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        i = 0;
        checkGPS();
        getLastLocation();

        // LocalBroadcastManager zapewnia dostarczenie broadcastów in-process
        // niezależnie od wersji Androida (na API 34+ globalny sendBroadcast()
        // + RECEIVER_NOT_EXPORTED może nie dostarczyć do receivera w tej samej app).
        IntentFilter filter = new IntentFilter(WalkingService.ACTION_STATE_UPDATE);
        LocalBroadcastManager.getInstance(this).registerReceiver(stateReceiver, filter);
        sendServiceCommand(WalkingService.ACTION_CMD_QUERY_STATE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(stateReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Serwis pozostaje żywy; zatrzyma się sam gdy użytkownik zresetuje
        // i wyjdzie z activity, albo przez ACTION_CMD_STOP
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Inicjalizacja widoków i listenerów
    // ─────────────────────────────────────────────────────────────────────────

    private void initViews() {
        btnPause      = findViewById(R.id.stop_button);
        btnReset      = findViewById(R.id.reset_button);
        btnStart      = findViewById(R.id.start_button);
        distanceText  = findViewById(R.id.distance);
        time          = findViewById(R.id.time_view);
        speedView     = findViewById(R.id.speed_view);
        btnMap        = findViewById(R.id.MapButn);
        progressBar   = findViewById(R.id.ProgressBar);

        btnPause.setVisibility(View.GONE);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupButtonListeners() {

        // ── Przycisk mapy ─────────────────────────────────────────────────────
        btnMap.setOnTouchListener((v, event) -> {
            if (mapClicked) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    playClick();
                    v.setScaleX(0.75f);
                    v.setScaleY(0.75f);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                }
            } else {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    playClick();
                    v.setScaleX(1.25f);
                    v.setScaleY(1.25f);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                }
            }
            return false;
        });

        btnMap.setOnClickListener(v -> {
            if (!mapClicked) {
                showMapFullscreen();
                mapClicked = true;
            } else {
                hideMapFullscreen();
                mapClicked = false;
            }
        });

        // ── Przycisk START ────────────────────────────────────────────────────
        btnStart.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                playClick();
                v.setBackgroundResource(R.drawable.start_line_clicked);
                v.setScaleX(0.9f);
                v.setScaleY(0.9f);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                v.setBackgroundResource(R.drawable.start_line);
                v.setScaleX(1.0f);
                v.setScaleY(1.0f);
            }
            return false;
        });

        btnStart.setOnClickListener(v -> {
            checkGPS();
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) return;

            // Na Androidzie 12+ uruchomienie foreground service z foregroundServiceType="location"
            // bez nadanego ACCESS_FINE_LOCATION/ACCESS_COARSE_LOCATION wywala SecurityException
            // (na Androidzie 16 jest to wymuszane bardzo restrykcyjnie) – jeśli nie mamy
            // uprawnień, dopytujemy o nie i nie startujemy serwisu.
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                }, 1000);
                return;
            }

            // Pokaż spinner; serwis powiadomi nas broadcastem gdy GPS lock uzyska
            btnReset.setVisibility(View.GONE);
            btnStart.setVisibility(View.GONE);
            btnPause.setVisibility(View.GONE);
            progressBar.setVisibility(View.VISIBLE);

            buttonInt = 1;
            p = 0;
            btnPause.setBackgroundResource(R.drawable.pause_button);

            // Startujemy serwis foreground
            Intent intent = new Intent(this, WalkingService.class);
            intent.setAction(WalkingService.ACTION_CMD_START);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent);
                } else {
                    startService(intent);
                }
                // Na nowszych Androidach (14/15/16) pierwszy broadcast ze stanem może
                // przyjść z opóźnieniem (np. zanim usługa zdąży wywołać startForeground).
                // Dopytujemy serwis o aktualny stan jako zabezpieczenie, żeby spinner
                // nie został widoczny w nieskończoność.
                new android.os.Handler(getMainLooper()).postDelayed(
                        () -> sendServiceCommand(WalkingService.ACTION_CMD_QUERY_STATE), 1500);

                // Twardy backstop: jeśli po 8s spinner wciąż widoczny (broadcast nie doszedł
                // z jakiegokolwiek powodu), chowamy go i wracamy do stanu początkowego,
                // żeby użytkownik nie został z wiecznym progress barem.
                new android.os.Handler(getMainLooper()).postDelayed(() -> {
                    if (progressBar.getVisibility() == View.VISIBLE) {
                        Log.w("WalkingActivity", "Spinner timeout – brak odpowiedzi serwisu po 8s");
                        progressBar.setVisibility(View.GONE);
                        btnStart.setVisibility(View.VISIBLE);
                        btnPause.setVisibility(View.GONE);
                        btnReset.setVisibility(View.GONE);
                        Toast.makeText(this, getString(R.string.permission_denied_toast), Toast.LENGTH_SHORT).show();
                    }
                }, 8000);
            } catch (Exception e) {
                // Np. SecurityException / ForegroundServiceStartNotAllowedException na Androidzie 14+/16,
                // gdy brak uprawnień lub usługa nie zdążyła wystartować w wymaganym czasie.
                Log.e("WalkingActivity", "Nie udało się uruchomić WalkingService", e);
                progressBar.setVisibility(View.GONE);
                btnStart.setVisibility(View.VISIBLE);
                Toast.makeText(this, getString(R.string.permission_denied_toast), Toast.LENGTH_SHORT).show();
            }
        });

        // ── Przycisk PAUZA / WZNÓW ────────────────────────────────────────────
        btnPause.setOnTouchListener((v, event) -> {
            if (buttonInt == 1) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    playClick();
                    v.setBackgroundResource(R.drawable.pause_button_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.setBackgroundResource(R.drawable.pause_button);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                }
            } else if (buttonInt == 2) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    playClick();
                    v.setBackgroundResource(R.drawable.pause_button_x_clicked);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.setBackgroundResource(R.drawable.pause_button_x);
                }
            }
            return false;
        });

        btnPause.setOnClickListener(v -> {
            if (buttonInt == 1) {
                // → Pauza
                buttonInt = 2;
                p = 1;
                btnPause.setBackgroundResource(R.drawable.pause_button_x);
                sendServiceCommand(WalkingService.ACTION_CMD_PAUSE);

            } else if (buttonInt == 2) {
                // → Wznów
                checkGPS();
                LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
                if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) return;

                buttonInt = 1;
                p = 0;
                btnPause.setBackgroundResource(R.drawable.pause_button);
                sendServiceCommand(WalkingService.ACTION_CMD_RESUME);
            }
        });

        // ── Przycisk RESET (Finish) ────────────────────────────────────────────
        btnReset.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                playClick();
                v.setBackgroundResource(R.drawable.finish_clicked);
                v.setScaleX(0.9f);
                v.setScaleY(0.9f);
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                v.setBackgroundResource(R.drawable.finish);
                v.setScaleX(1.0f);
                v.setScaleY(1.0f);
            }
            return false;
        });

        btnReset.setOnClickListener(v -> {
            p = 2;
            buttonInt = 1;

            btnStart.setVisibility(View.VISIBLE);
            btnPause.setVisibility(View.GONE);
            btnPause.setBackgroundResource(R.drawable.pause_button);

            // Zerujemy wyświetlane wartości
            lastDistance = 0.0;
            lastSeconds  = 0;
            lastSpeed    = 0.0;
            refreshTextViews();

            sendServiceCommand(WalkingService.ACTION_CMD_RESET);

            // Zatrzymujemy foreground service (powiadomienie znika)
            sendServiceCommand(WalkingService.ACTION_CMD_STOP);
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Aktualizacja UI na podstawie stanu serwisu
    // ─────────────────────────────────────────────────────────────────────────

    @SuppressLint("DefaultLocale")
    private void updateUiFromState() {
        // Chowamy spinner TYLKO gdy serwis przyśle stan running==true lub paused==true,
        // czyli faktyczny start treningu się powiódł.
        //
        // UWAGA: nie chowamy spinnera dla running==false/paused==false – taka odpowiedź
        // może być "przedwczesnym" wynikiem ACTION_CMD_QUERY_STATE (wysłanym z opóźnieniem
        // 1500ms po starcie), zanim handleStart() w serwisie zdążył ustawić running=true
        // (startForeground bywa wolny, patrz startForegroundDelayMs w logach). Jeśli
        // wtedy schowalibyśmy spinner i pokazali btnStart, to później prawdziwy
        // broadcastState() z running=true przyjdzie gdy progressBar jest już GONE,
        // warunek się nie wykona i UI zatrzyma się na "Start" mimo że serwis działa.
        //
        // Przypadki "trening nie wystartował" (brak uprawnień / startForeground failed /
        // brak odpowiedzi serwisu) są obsługiwane osobno: przez EXTRA_ERROR_NO_LOCATION_PERMISSION
        // powyżej i przez 8-sekundowy timeout w btnStart.onClick.
        if (progressBar.getVisibility() == View.VISIBLE && (running || paused)) {
            progressBar.setVisibility(View.GONE);
            btnPause.setVisibility(View.VISIBLE);
            btnReset.setVisibility(View.VISIBLE);
        }

        // Synchronizuj buttonInt ze stanem serwisu
        if (running && !paused) {
            buttonInt = 1;
            btnStart.setVisibility(View.GONE);
            btnPause.setVisibility(View.VISIBLE);
            btnReset.setVisibility(View.VISIBLE);
            btnPause.setBackgroundResource(R.drawable.pause_button);
        } else if (paused) {
            buttonInt = 2;
            btnStart.setVisibility(View.GONE);
            btnPause.setVisibility(View.VISIBLE);
            btnReset.setVisibility(View.VISIBLE);
            btnPause.setBackgroundResource(R.drawable.pause_button_x);
        }

        refreshTextViews();
    }

    private void refreshTextViews() {
        int hours   = lastSeconds / 3600;
        int minutes = (lastSeconds % 3600) / 60;
        int secs    = lastSeconds % 60;

        String timeStr     = getString(R.string.time_format, hours, minutes, secs);
        String distanceStr = getString(R.string.distance_format, lastDistance);
        String speedStr    = getString(R.string.speed_format, lastSpeed);

        time.setText(timeStr);
        distanceText.setText(distanceStr);
        speedView.setText(speedStr);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Mapa
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        getLastLocation();
    }


    private void getLastLocation() {
        if (map == null) return;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)   == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(task -> {
                android.location.Location location = task.getResult();
                if (location != null) {
                    if (markerProfil != null) markerProfil.remove();



                    BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.locate);
                    latLng        = new LatLng(location.getLatitude(), location.getLongitude());
                    markerOptions = new MarkerOptions()
                            .position(latLng)
                            .title(getString(R.string.location_title))
                            .icon(icon);
                    CameraPosition cameraPosition = new CameraPosition(latLng, 17, 0, 0);
                    map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                    markerProfil = map.addMarker(markerOptions);
                }
            });
        }
        // Uwaga: jeśli uprawnienia lokalizacji nie są przyznane, NIE wołamy tutaj
        // requestPermissions(). onCreate() już o nie prosi raz, przy starcie Activity.
        // Wywołanie requestPermissions() z dwóch miejsc praktycznie w tym samym
        // momencie (onCreate -> onResume -> getLastLocation, wywoływane przez
        // onMapReady) powoduje, że system potrafi natychmiast zamknąć/odrzucić
        // pierwszy lub drugi dialog jako "Don't allow", mimo że użytkownik
        // nic nie kliknął.
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Widok mapy pełnoekranowy
    // ─────────────────────────────────────────────────────────────────────────

    private void showMapFullscreen() {
        distanceText.setVisibility(View.GONE);
        speedView.setVisibility(View.GONE);
        time.setVisibility(View.GONE);
        btnStart.setVisibility(View.GONE);
        btnReset.setVisibility(View.GONE);
        btnPause.setVisibility(View.GONE);
        toolbar.setVisibility(View.GONE);
        btnMap.setBackgroundResource(R.drawable.minimize);
    }

    private void hideMapFullscreen() {
        distanceText.setVisibility(View.VISIBLE);
        speedView.setVisibility(View.VISIBLE);
        time.setVisibility(View.VISIBLE);
        toolbar.setVisibility(View.VISIBLE);

        if (!running && buttonInt != 2) {
            btnStart.setVisibility(View.VISIBLE);
        }
        if (p == 2) {
            btnPause.setVisibility(View.GONE);
        } else {
            btnPause.setVisibility(View.VISIBLE);
        }
        btnReset.setVisibility(View.VISIBLE);
        btnMap.setBackgroundResource(R.drawable.enlarge);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  GPS check
    // ─────────────────────────────────────────────────────────────────────────

    private void checkGPS() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            showGPSDisabledAlert();
        }
    }

    private void showGPSDisabledAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.gps_enable_message))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.gps_enable_button),
                        (dialog, which) -> startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                .setNegativeButton(getString(R.string.cancel),
                        (dialog, which) -> dialog.cancel());

        AlertDialog alert = builder.create();
        alert.setIcon(R.mipmap.icon_launcher);
        if (alert.getWindow() != null) {
            alert.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        }
        alert.show();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Menu
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.walking, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_share) {
            takeScreenShot(getWindow().getDecorView());
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Back press
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        playClick();

        if (running) {
            if (i == 0) {
                Toast.makeText(this, getString(R.string.turnOFf), Toast.LENGTH_SHORT).show();
            }
            if (i >= 2) {
                sendServiceCommand(WalkingService.ACTION_CMD_STOP);
                super.onBackPressed();
            }
            i++;
        } else {
            sendServiceCommand(WalkingService.ACTION_CMD_STOP);
            super.onBackPressed();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  onSaveInstanceState
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putDouble("speed",     lastSpeed);
        outState.putDouble("training1", lastDistance);
        outState.putInt("secs",         lastSeconds);
        outState.putBoolean("running",  running);
        super.onSaveInstanceState(outState);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  onRequestPermissionsResult
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != 1000) return;

        boolean locationGranted      = false;
        boolean notificationsGranted = true; // domyślnie true – na API < 33 nie jest wymagane
        boolean anyImportantDenied   = false;

        for (int i = 0; i < permissions.length; i++) {
            boolean granted = grantResults[i] == PackageManager.PERMISSION_GRANTED;
            switch (permissions[i]) {
                case Manifest.permission.ACCESS_FINE_LOCATION:
                    locationGranted = granted;
                    if (!granted) anyImportantDenied = true;
                    break;
                case Manifest.permission.POST_NOTIFICATIONS:
                    notificationsGranted = granted;
                    if (!granted) anyImportantDenied = true;
                    break;
                // WRITE/READ_EXTERNAL_STORAGE: ignorujemy – na Android 10+
                // aplikacja używa getExternalFilesDir() i nie potrzebuje tych uprawnień.
                // ACCESS_COARSE_LOCATION: ignorujemy – przyznawane automatycznie z FINE.
            }
        }

        if (locationGranted || notificationsGranted) {
            Toast.makeText(this, getString(R.string.permission_granted), Toast.LENGTH_SHORT).show();
        }
        if (anyImportantDenied) {
            Toast.makeText(this, getString(R.string.permission_denied_toast), Toast.LENGTH_SHORT).show();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Screenshot / share
    // ─────────────────────────────────────────────────────────────────────────

    private void takeScreenShot(View view) {
        if (map == null) return;
        map.snapshot(bitmap -> {
            if (bitmap == null) {
                // Fallback: tylko widok
                Date date = new Date();
                CharSequence format = DateFormat.format("MM-dd-yyyy_hh:mm:ss", date);
                try {
                    File mainDir = new File(
                            getExternalFilesDir(Environment.DIRECTORY_PICTURES), "FilShare");
                    if (!mainDir.exists()) mainDir.mkdir();

                    String path = mainDir + "/TrendOceans-" + format + ".jpeg";
                    view.setDrawingCacheEnabled(true);
                    Bitmap bitmapScreen = Bitmap.createBitmap(view.getDrawingCache());
                    view.setDrawingCacheEnabled(false);

                    File imageFile = new File(path);
                    FileOutputStream fos = new FileOutputStream(imageFile);
                    bitmapScreen.compress(Bitmap.CompressFormat.PNG, 90, fos);
                    fos.flush();
                    fos.close();
                    shareScreenShot(imageFile);
                } catch (IOException e) {
                    Log.e("WalkingActivity", "Screenshot error", e);
                }
            } else {
                view.setDrawingCacheEnabled(true);
                Bitmap viewBitmap = Bitmap.createBitmap(view.getDrawingCache());
                view.setDrawingCacheEnabled(false);
                saveBitmap(combineBitmaps(bitmap, viewBitmap));
            }
        });
    }

    private void saveBitmap(Bitmap bitmap) {
        Date date = new Date();
        CharSequence format = DateFormat.format("MM-dd-yyyy_hh:mm:ss", date);
        try {
            File mainDir = new File(
                    getExternalFilesDir(Environment.DIRECTORY_PICTURES), "FilShare");
            if (!mainDir.exists()) mainDir.mkdir();

            File imageFile = new File(mainDir + "/TrendOceans-" + format + ".jpeg");
            FileOutputStream fos = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, fos);
            fos.flush();
            fos.close();
            shareScreenShot(imageFile);
        } catch (IOException e) {
            Log.e("WalkingActivity", "saveBitmap error", e);
        }
    }

    private Bitmap combineBitmaps(Bitmap mapBitmap, Bitmap viewBitmap) {
        Bitmap combined = Bitmap.createBitmap(
                viewBitmap.getWidth(), viewBitmap.getHeight(), viewBitmap.getConfig());
        android.graphics.Canvas canvas = new android.graphics.Canvas(combined);
        canvas.drawBitmap(viewBitmap, 0, 0, null);

        View mapFragmentView = findViewById(R.id.map);
        int[] location = new int[2];
        mapFragmentView.getLocationOnScreen(location);
        canvas.drawBitmap(mapBitmap, location[0], location[1], null);

        return combined;
    }

    private void shareScreenShot(File imageFile) {
        Uri uri = FileProvider.getUriForFile(
                this,
                BuildConfig.APPLICATION_ID + ".activity.WalkingActivity.provider",
                imageFile);

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_TEXT,   getString(R.string.sample_app_screenshot_text));
        intent.putExtra(Intent.EXTRA_STREAM, uri);

        try {
            startActivity(Intent.createChooser(intent, getString(R.string.share_with)));
        } catch (android.content.ActivityNotFoundException e) {
            Toast.makeText(this, getString(R.string.no_app_available), Toast.LENGTH_SHORT).show();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Pomocnicze
    // ─────────────────────────────────────────────────────────────────────────

    private void sendServiceCommand(String action) {
        Intent intent = new Intent(this, WalkingService.class);
        intent.setAction(action);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && WalkingService.ACTION_CMD_START.equals(action)) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void playClick() {
        MediaPlayer clickAlert = MediaPlayer.create(this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }
}
