package com.sm.github_debug_demo.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.Toast;


import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.sm.github_debug_demo.data.QuestionsDatabaseHelper;
import com.sm.github_debug_demo.R;

public class StartingPage3 extends AppCompatActivity {


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_page3);



        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        Button trainingamator = findViewById(R.id.training_amator);
       Button trainingsemi = findViewById(R.id.training_semi_professional);
        Button trainingpro = findViewById(R.id.training_professional);


        trainingamator.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.training_amator_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setBackgroundResource(R.drawable.training_amator);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        trainingsemi.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.training_semi_professional_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setBackgroundResource(R.drawable.training_semi_professional);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        trainingpro.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.training_professional_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setBackgroundResource(R.drawable.training_professional);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        trainingamator.setOnClickListener(view -> {
            try {
                SQLiteOpenHelper questionsDatabaseHelper = new QuestionsDatabaseHelper(this);
                SQLiteDatabase db = questionsDatabaseHelper.getWritableDatabase();

                ContentValues Info1 = new ContentValues();
                Info1.put("TRENING", getString(R.string.trainingAmator));

                db.update("INFO1", Info1, "_id = ?", new String[]{Integer.toString(1)});

                ContentValues Info2 = new ContentValues();
                Info2.put("TRAINING1", 1);

                db.update("INFO1", Info2, "_id = ?", new String[]{Integer.toString(1)});

                db.close();

                Intent intent = new Intent(StartingPage3.this, StartingPage4.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(StartingPage3.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
            }
        });


        trainingsemi.setOnClickListener(view -> {
            try {
                SQLiteOpenHelper questionsDatabaseHelper = new QuestionsDatabaseHelper(this);
                SQLiteDatabase db = questionsDatabaseHelper.getWritableDatabase();

                ContentValues Info1 = new ContentValues();
                Info1.put("TRENING", getString(R.string.trainingSemiProfessional));

                db.update("INFO1", Info1, "_id = ?", new String[]{Integer.toString(1)});

                ContentValues Info2 = new ContentValues();
                Info2.put("TRAINING1", 2);

                db.update("INFO1", Info2, "_id = ?", new String[]{Integer.toString(1)});

                db.close();

                Intent intent = new Intent(StartingPage3.this, StartingPage4.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(StartingPage3.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
            }
        });
        trainingpro.setOnClickListener(view -> {
            try {
                SQLiteOpenHelper questionsDatabaseHelper = new QuestionsDatabaseHelper(this);
                SQLiteDatabase db = questionsDatabaseHelper.getWritableDatabase();

                ContentValues Info1 = new ContentValues();
                Info1.put("TRENING", getString(R.string.trainingProfessional));

                db.update("INFO1", Info1, "_id = ?", new String[]{Integer.toString(1)});

                ContentValues Info2 = new ContentValues();
                Info2.put("TRAINING1", 3);

                db.update("INFO1", Info2, "_id = ?", new String[]{Integer.toString(1)});

                db.close();

                Intent intent = new Intent(StartingPage3.this, StartingPage4.class);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(StartingPage3.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
            }
        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert =MediaPlayer.create(StartingPage3.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }


}