package com.sm.github_debug_demo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;


import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;

import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import com.sm.github_debug_demo.Menu.PrivatePolicyURLActivity;
import com.sm.github_debug_demo.Menu.ProducentsInfoActivity;
import com.github.mikephil.charting.data.Entry;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.model.UpdateInfo;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Calendar;

public class MenuActivity extends AppCompatActivity {

    FirebaseAuth firebaseAuth;

    private int Connected;
    private String id;
    private String userName;

    private FirebaseDatabase firebaseDatabase;

    private double Water1;

    private boolean fail;

    private  double Weight;
    private  double Height;
    private int Age;
    private String Gender;

    private double Kcal1;
    private double Kcal2;

    private double BMI;

    private int Diet1;
    private int Training1;
    private int GenderInt;
    private int Connection;
    private int Day;
    private int newDay;
    private double newWeight;
    private boolean newWeightBoolean;
    private ArrayList<Entry> dataVals;
    private int size;
    private int newWeightInt;
    private String updateInfo;
    private double WaterMax;
    private String langOption;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();


        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        dataVals = new ArrayList<>();


        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        CardView menu1 = findViewById(R.id.menu1);
        CardView menu2 = findViewById(R.id.menu2);
        CardView menu3 = findViewById(R.id.menu3);
        CardView menu4 = findViewById(R.id.menu4);
        CardView menu5 = findViewById(R.id.menu5);
        CardView menu6 = findViewById(R.id.menu6);
        CardView menu7 = findViewById(R.id.menu7);
        CardView menu8 = findViewById(R.id.menu8);

        menu1.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu2.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu3.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu4.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu5.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu6.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu7.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);;
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        menu8.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        menu1.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, TrainingListActivity.class);
            startActivity(intent);
        });
        menu2.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, DietListActivity.class);
            startActivity(intent);
        });
        menu3.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, WalkingActivity.class);
            startActivity(intent);
        });
        menu4.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, ChartActivity.class);
            startActivity(intent);
        });
        menu5.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, WaterActivity.class);
            startActivity(intent);
        });
        menu6.setOnClickListener(view -> {
            Intent intent = new Intent(MenuActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        menu7.setOnClickListener(view -> ResetAlert());

        menu8.setOnClickListener(view -> System.exit(0));


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        MediaPlayer clickAlert1 =MediaPlayer.create(MenuActivity.this, R.raw.click);
        if (clickAlert1 != null) clickAlert1.start();
        if (id == R.id.action_logout) {
            Toast.makeText(MenuActivity.this, getString(R.string.Logout), Toast.LENGTH_SHORT).show();

            FirebaseAuth.getInstance().signOut();
            goToLogin();

            return true;
        }
        if (id == R.id.private_policy) {
            Intent intent = new Intent(MenuActivity.this, PrivatePolicyURLActivity.class);
            startActivity(intent);

            return true;
        }
        if (id == R.id.producents_info) {
            Intent intent = new Intent(MenuActivity.this, ProducentsInfoActivity.class);
            startActivity(intent);

            return true;
        }

        if (id == R.id.updateInfoMenu)
        {
            ReadPatchInfo();
            return true;
        }

        if (id == R.id.action_delete_account) {
            showDeleteAccountDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showDeleteAccountDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.delete_account_confirm_title);
        builder.setMessage(R.string.delete_account_confirm_message);
        builder.setPositiveButton(R.string.continuee, (dialog, which) -> deleteAccount());
        builder.setNegativeButton(R.string.cancel, (dialog, which) -> dialog.dismiss());
        AlertDialog dialog = builder.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        dialog.show();
    }

    private void deleteAccount() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            // First remove user data from Database
            firebaseDatabase.getReference().child("users").child(id).removeValue()
                    .addOnCompleteListener(task -> {
                        // Then delete the account from Firebase Auth
                        user.delete().addOnCompleteListener(authTask -> {
                            if (authTask.isSuccessful()) {
                                Toast.makeText(MenuActivity.this, R.string.account_deleted, Toast.LENGTH_SHORT).show();
                                goToLogin();
                            } else {
                                Toast.makeText(MenuActivity.this, R.string.delete_account_error, Toast.LENGTH_LONG).show();
                                // Sign out anyway if delete fails due to auth timeout
                                firebaseAuth.signOut();
                                goToLogin();
                            }
                        });
                    });
        }
    }

    public void goToLogin()
    {
        Intent intent = new Intent(MenuActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void getNameAndId()
    {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            id = user.getUid();
            String displayName = user.getDisplayName();
            if (displayName != null) {
                userName = StringUtils.substringBefore(displayName, "@");
            } else {
                userName = getString(R.string.default_user_name);
            }
        }
    }

    private void ReadOrInitFromFirebase1() {

        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if (dataSnapshot.exists()) {
                        Person newPerson = dataSnapshot.getValue(Person.class);
                        if (newPerson != null) {
                            Connected = newPerson.Connected;
                            Connection = newPerson.Connection;
                            Water1 = newPerson.Water;
                            GenderInt = newPerson.GenderId;
                            BMI = newPerson.BMI;
                            Kcal2 = newPerson.KcalTraining;
                            Kcal1 = newPerson.KcalNormal;
                            Training1 = newPerson.Training;
                            Diet1 = newPerson.Diet;
                            Gender = newPerson.Gender;
                            Age = newPerson.Age;
                            Weight = newPerson.Weight;
                            Height = newPerson.Height;
                            Day = newPerson.Day;
                            newWeight = newPerson.NewWeight;
                            newWeightBoolean = newPerson.NewWeightBoolean;
                            dataVals = newPerson.dataVals;
                            WaterMax = newPerson.WaterMax;


                            getDay();

                            if (Day != newDay) {
                                Water1 = 0;
                                kgAlert();
                            }

                            if (Connected == 0) {
                                Intent intent = new Intent(MenuActivity.this, StartingPage1.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }
                    else
                    {

                        Toast.makeText(MenuActivity.this, getString(R.string.db_problem), Toast.LENGTH_LONG).show();

                        FirebaseAuth.getInstance().signOut();
                        goToLogin();
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(MenuActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }



    }

    private void getDay()
    {
        Calendar calendar = Calendar.getInstance();
        newDay = calendar.get(Calendar.DAY_OF_WEEK);

    }

    private void SaveInFirebase()
    {
        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    Person person = new Person(userName, id, newWeight, Height, Age, Gender, Diet1, Training1, Kcal1, Kcal2, BMI, Connected, Connection, GenderInt, Water1, newDay, newWeight, newWeightBoolean, WaterMax, dataVals);
                    firebaseDatabase.getReference().child("users").child(id).setValue(person);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(MenuActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }
    }

    private void kgAlert()
    {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        final EditText edittext = new EditText(this);
        edittext.setInputType(3);
        alert.setMessage(getString(R.string.kgalert));
        alert.setTitle(getString(R.string.currentWeightUser));

        alert.setView(edittext);

        alert.setPositiveButton(getString(R.string.continuee), (dialog, whichButton) -> {

            try {
                String YouEditTextValue = edittext.getText().toString();
                newWeight = Double.parseDouble(YouEditTextValue);

                fail=false;

                BMI = newWeight/((Height/100)*(Height/100));
                BMI = Math.round(BMI*100);
                BMI = BMI/100;

                double BMR = 0;

                if (GenderInt==1)
                {
                    BMR = (9.99 * newWeight) + (6.25 * Height) - (4.92 * Age) + 5;
                    BMR = Math.round(BMR*100);
                    BMR = BMR/100;
                }
                else if (GenderInt==2)
                {
                    BMR = (9.99 * newWeight) + (6.25 * Height) - (4.92 * Age) -161;
                    BMR = Math.round(BMR*100);
                    BMR = BMR/100;
                }

                if (Diet1 ==1)
                {
                    Kcal1 = BMR*1.2;


                    if (Training1 ==1)
                    {
                        Kcal2 = BMR*1.3;
                    }
                    else if (Training1 ==2)
                    {
                        Kcal2 = BMR*1.35;
                    }
                    else if (Training1 ==3)
                    {
                        Kcal2 = BMR*1.4;
                    }
                }

                else  if (Diet1 ==2)
                {
                    Kcal1 = BMR*1.3;

                    if (Training1 ==1)
                    {
                        Kcal2 = BMR*1.4;
                    }
                    else if (Training1 ==2)
                    {
                        Kcal2 = BMR*1.5;
                    }
                    else if (Training1 ==3)
                    {
                        Kcal2 = BMR*1.6;
                    }
                }

                Kcal1 = Math.round(Kcal1*100);
                Kcal1 = Kcal1/100;
                Kcal2 = Math.round(Kcal2*100);
                Kcal2= Kcal2/100;


                WaterMax = Weight*0.035;
                WaterMax = Math.round(WaterMax*100);
                WaterMax = WaterMax/100;

                if (Training1==2)
                {
                    WaterMax = WaterMax+0.2;
                }
                else if (Training1==3)
                {
                    WaterMax = WaterMax+0.5;
                }

            }
            catch (Exception e)
            {


                Toast.makeText(MenuActivity.this, getString(R.string.badWords), Toast.LENGTH_SHORT).show();
                fail = true;
                kgAlert();
            }

            if (!fail)
            {
                ReadOrInitFromFirebaseChart();
                SaveInFirebase();

            }
            MediaPlayer clickAlert1 =MediaPlayer.create(MenuActivity.this, R.raw.click);
            if (clickAlert1 != null) clickAlert1.start();


        });
        AlertDialog dialog = alert.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            getNameAndId();
            ReadOrInitFromFirebase1();


        }
        else
        {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void ReadOrInitFromFirebaseChart() {

        try {

            firebaseDatabase.getReference().child("users").child(id).child("dataVals").addListenerForSingleValueEvent(new ValueEventListener() {
                @SuppressLint("SuspiciousIndentation")
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    if (dataSnapshot.exists()) {


                        size = (int) dataSnapshot.getChildrenCount();


                        newWeightInt = (int) newWeight;



                            dataVals.add(new Entry(size+1, newWeightInt));
                            SaveInFirebase();


                    }
                    else
                    {



                        Toast.makeText(MenuActivity.this, getString(R.string.db_problem), Toast.LENGTH_LONG).show();
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


        } catch (Exception e) {

            dataVals.add(new Entry(1, newWeightInt));
            if (Weight != newWeight)
            {
                Weight = newWeight;
            }

            Person person = new Person(userName, id, Weight, Height, Age, Gender, Diet1, Training1, Kcal1, Kcal2, BMI, Connected, Connection, GenderInt, Water1, newDay, newWeight, newWeightBoolean, WaterMax, dataVals);
            firebaseDatabase.getReference().child("users").child(id).setValue(person);
            Toast.makeText(MenuActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }

    }

    private void ReadPatchInfo()
    {
        if (getString(R.string.language).equals(getString(R.string.language_code_pl)))
        {
            langOption = getString(R.string.information_path);
        }
        else
        {
            langOption = getString(R.string.information_eng_path);
        }

        try {
            firebaseDatabase.getReference().child(langOption).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.exists()) {

                        UpdateInfo updateInfoObject = dataSnapshot.getValue(UpdateInfo.class);
                        if (updateInfoObject != null) {
                            updateInfo = updateInfoObject.updateInfo;
                        }
                    }
                    else
                    {
                        updateInfo = getString(R.string.noInfo);

                    }
                    View view = new View(getApplicationContext());
                    showAlertDialogButtonClicked(view);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(MenuActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();

        }
    }

    public void showAlertDialogButtonClicked(View view) {


        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MenuActivity.this);
        builder.setTitle(getString(R.string.update_info_title));
        builder.setMessage(updateInfo);


        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MediaPlayer clickAlert1 =MediaPlayer.create(MenuActivity.this, R.raw.click);
                if (clickAlert1 != null) clickAlert1.start();
            }
        });


        android.app.AlertDialog dialog = builder.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert =MediaPlayer.create(MenuActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }

    private void ResetAlert() {

        AlertDialog.Builder alert = new AlertDialog.Builder(MenuActivity.this);

        alert.setMessage(getString(R.string.noReturn));
        alert.setTitle(getString(R.string.resetApp));

        alert.setPositiveButton(getString(R.string.continuee), (dialog, whichButton) -> SaveInFirebaseNull());

        alert.setNegativeButton(getString(R.string.cancel), (dialog, which) -> {

        });
        AlertDialog dialog = alert.create();
        dialog.setIcon(R.mipmap.icon_launcher);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        dialog.show();

    }
    private void SaveInFirebaseNull()
    {
        boolean fail = false;
        try {
            Person person = new Person(userName, id, 0, 0, 0, getString(R.string.lack), 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, false, 0, dataVals);
            firebaseDatabase.getReference().child("users").child(id).setValue(person);
        }
        catch (Exception e)
        {
            fail = true;
        }
        finally {
            if (!fail)
            {
                goToLogin();

            }
            else
            {
                Toast.makeText(MenuActivity.this, getString(R.string.db_connection_error), Toast.LENGTH_SHORT).show();
            }

        }
    }
}
