package com.sm.github_debug_demo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.model.TrainingDayMassMedium;
import com.sm.github_debug_demo.model.TrainingDayReductionMedium;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment1;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment10;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment11;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment12;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment2;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment3;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment4;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment5;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment6;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment7;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment8;
import com.sm.github_debug_demo.fragments.TrainingDetailFragment9;

public class TrainingActivity extends AppCompatActivity {


    public static final String EXTRA_TRAINING_ID = "trainingId";

    private int Diet1;
    private int Training1;

    private String id;

    private FirebaseDatabase firebaseDatabase;
    private int trainingId;
    private int trainingLenght;
    private TextView textView;




    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training);

        firebaseDatabase = FirebaseDatabase.getInstance();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            getNameAndId();
            ReadOrInitFromFirebase1();
        }
         trainingId = (Integer)getIntent().getExtras().get(EXTRA_TRAINING_ID);

        textView = findViewById(R.id.textDay);
        textView.setText(getString(R.string.day) + " " + (trainingId + 1));

        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }

    @Override
    public boolean onSupportNavigateUp() {
        MediaPlayer clickAlert = MediaPlayer.create(TrainingActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();

        if (isTaskRoot()) {
            Intent intent = new Intent(this, MenuActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        }
    else {
        navigateUpTo(new Intent(this, MenuActivity.class));
    }
        return true;
    }


    public int getTrainingId() {
        return trainingId;
    }

    private void getNameAndId()
    {
        String  idNumber;
        idNumber = FirebaseAuth.getInstance().getCurrentUser().getUid();
        id = idNumber;
    }

    private void ReadOrInitFromFirebase1() {

        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.exists()) {
                        Person newPerson = dataSnapshot.getValue(Person.class);

                        if (newPerson != null) {
                            Training1 = newPerson.Training;
                            Diet1 = newPerson.Diet;

                            SectionsPagerAdapter pagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
                            ViewPager pager = (ViewPager) findViewById(R.id.pager);
                            pager.setAdapter(pagerAdapter);
                        }
                    } else {
                        Toast.makeText(TrainingActivity.this, getString(R.string.db_problem), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Toast.makeText(TrainingActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
        }
    }


    private class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm)
        {
            super(fm);
        }

        @Override
        public int getCount() {
                    getTrainingLenght(Training1, Diet1);
                    return trainingLenght;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
                switch (position)
                {
                    case 0:

                        return new TrainingDetailFragment1();
                    case 1:
                        return new TrainingDetailFragment2();
                    case 2:

                        return new TrainingDetailFragment3();
                    case 3:

                        return new TrainingDetailFragment4();
                    case 4:

                        return new TrainingDetailFragment5();
                    case 5:

                        return new TrainingDetailFragment6();
                    case 6:

                        return new TrainingDetailFragment7();
                    case 7:

                        return new TrainingDetailFragment8();
                    case 8:

                        return new TrainingDetailFragment9();
                    case 9:

                        return new TrainingDetailFragment10();
                    case 10:

                        return new TrainingDetailFragment11();
                    case 11:

                        return new TrainingDetailFragment12();
                }
            return null;
        }
    }

    public int trainingId() {
        return trainingId;
    }

    public int getDiet1() {
        return Diet1;
    }

    public int getTraining1() {
        return Training1;
    }

    private void getTrainingLenght (int Training1, int Diet1 ) {

        if (Diet1 == 1) {
                    if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining11() == null) {
                        if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining10() == null) {
                            if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining9() == null) {
                                if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining8() == null) {
                                    if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining7() == null) {
                                        if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining6() == null) {
                                            if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining5() == null) {
                                                if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining4() == null) {
                                                    if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining3() == null) {
                                                        if (TrainingDayReductionMedium.trainingDayReductionMedium[trainingId].getTraining2() == null) {
                                                            trainingLenght = 1;
                                                        } else {
                                                            trainingLenght = 2;
                                                        }
                                                    } else {
                                                        trainingLenght = 3;
                                                    }
                                                } else {
                                                    trainingLenght = 4;
                                                }
                                            } else {
                                                trainingLenght = 5;
                                            }
                                        } else {
                                            trainingLenght = 6;
                                        }
                                    } else {
                                        trainingLenght = 7;
                                    }
                                } else {
                                    trainingLenght = 8;
                                }
                            } else {
                                trainingLenght = 9;
                            }
                        } else {
                            trainingLenght = 10;
                        }

                    } else {
                        trainingLenght = 11;
                    }

        }

        if (Diet1 == 2) {

                if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining12() == null) {
                    if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining11() == null) {
                        if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining10() == null) {
                            if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining9() == null) {
                                if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining8() == null) {
                                    if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining7() == null) {
                                        if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining6() == null) {
                                            if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining5() == null) {
                                                if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining4() == null) {
                                                    if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining3() == null) {
                                                        if (TrainingDayMassMedium.trainingDayMassMedium[trainingId].getTraining2() == null) {
                                                            trainingLenght = 1;
                                                        } else {
                                                            trainingLenght = 2;
                                                        }
                                                    } else {
                                                        trainingLenght = 3;
                                                    }
                                                } else {
                                                    trainingLenght = 4;
                                                }
                                            } else {
                                                trainingLenght = 5;
                                            }
                                        } else {
                                            trainingLenght = 6;
                                        }
                                    } else {
                                        trainingLenght = 7;
                                    }
                                } else {
                                    trainingLenght = 8;
                                }
                            } else {
                                trainingLenght = 9;
                            }
                        } else {
                            trainingLenght = 10;
                        }
                    } else {
                        trainingLenght = 11;
                    }

                } else {
                    trainingLenght = 12;
                }

            }

    }

    @Override
    public void onBackPressed() {
        MediaPlayer clickAlert = MediaPlayer.create(TrainingActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();

        // Jeśli stos jest pusty, otwórz MenuActivity zamiast zamykać aplikację
        if (isTaskRoot()) {
            Intent intent = new Intent(this, MenuActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } else {
            super.onBackPressed();
        }
    }
}