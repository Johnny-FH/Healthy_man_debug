package com.sm.github_debug_demo.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.data.Entry;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.sm.github_debug_demo.model.Person;
import com.sm.github_debug_demo.R;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Objects;


public class WaterActivity extends AppCompatActivity {

    private double Water1;

    private FirebaseDatabase firebaseDatabase;

    private String id;
    private String userName;

    private  double Weight;
    private  double Height;
    private int Age;
    private String Gender;


    private double Kcal1;
    private double Kcal2;

    private double BMI;

    private int Diet1;
    private int Training1;
    private int GenderInt;
    private int Connected;
    private int Connection;
    private int newDay;
    private double newWeight;
    private boolean NewWeightBoolean;

    private double WaterMax;
    private ArrayList<Entry> dataVals;
    ImageView waterProgress;

    TextView waterText;


    @SuppressLint({"ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water);

        Toolbar toolbar = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        AdView mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        dataVals = new ArrayList<>();

        firebaseDatabase = FirebaseDatabase.getInstance();

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            getNameAndId();
            ReadOrInitFromFirebase1();
        }


        ImageButton watterButton = findViewById(R.id.onClickAddWatter);

        watterButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setBackgroundResource(R.drawable.water_icon_clicked);
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setBackgroundResource(R.drawable.water_icon);
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });
        watterButton.setOnClickListener(view -> {
            showAddWaterDialog();
        });

        ImageButton resetWaterButton = findViewById(R.id.onClickResetWater);

        resetWaterButton.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN: {
                    MediaPlayer clickAlert =MediaPlayer.create(this, R.raw.click);
                    if (clickAlert != null) clickAlert.start();
                    v.setScaleX(0.9f);
                    v.setScaleY(0.9f);
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    v.setScaleX(1.0f);
                    v.setScaleY(1.0f);
                    break;
                }
            }
            return false;
        });

        resetWaterButton.setOnClickListener(view -> {
            MediaPlayer clickAlert = MediaPlayer.create(this, R.raw.click);
            if (clickAlert != null) clickAlert.start();
            Water1 = 0;
            waterText = findViewById(R.id.waterText);
            waterText.setText(getString(R.string.drinked_format, getString(R.string.drinked), Water1, WaterMax));
            SaveInFirebase();
            waterProgress();
            Toast.makeText(this, getString(R.string.hydration_reset), Toast.LENGTH_SHORT).show();
        });
    }

    private void showAddWaterDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.water));

        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(20); // Scale 0 to 1.0l with 0.05l steps
        seekBar.setPadding(60, 40, 60, 40);

        final TextView amountText = new TextView(this);
        amountText.setPadding(0, 40, 0, 10);
        amountText.setText(getString(R.string.zero_liters));
        amountText.setTextSize(24);
        amountText.setGravity(Gravity.CENTER);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        layout.addView(amountText);
        layout.addView(seekBar);
        builder.setView(layout);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                double amount = progress * 0.05;
                amountText.setText(getString(R.string.liters_format, amount));
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        builder.setPositiveButton(getString(R.string.continuee), (dialog, which) -> {
            double addedAmount = seekBar.getProgress() * 0.05;
            if (addedAmount > 0) {
                Water1 = Water1 + addedAmount;
                Water1 = Math.round(Water1 * 100.0) / 100.0;

                if (waterText == null) waterText = findViewById(R.id.waterText);
                waterText.setText(getString(R.string.drinked_format, getString(R.string.drinked), Water1, WaterMax));

                SaveInFirebase();
                waterProgress();

                MediaPlayer clickAlert = MediaPlayer.create(this, R.raw.click);
                if (clickAlert != null) clickAlert.start();
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.dismiss());

        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(R.drawable.password_background);
        }
        dialog.show();
    }



    private void SaveInFirebase() {
        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    Person person =  new Person(userName, id, Weight, Height, Age, Gender, Diet1, Training1, Kcal1, Kcal2, BMI, Connected, Connection, GenderInt, Water1, newDay, newWeight, NewWeightBoolean, WaterMax, dataVals);
                    firebaseDatabase.getReference().child("users").child(id).setValue(person);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            Toast.makeText(WaterActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
        }
    }

    private void getNameAndId() {
        String  idNumber;
        String firebaseEmail = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getDisplayName();
        userName = StringUtils.substringBefore(firebaseEmail, "@");
        idNumber = FirebaseAuth.getInstance().getCurrentUser().getUid();
        id = idNumber;
    }

    private void ReadOrInitFromFirebase1() {

        try {
            firebaseDatabase.getReference().child("users").child(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if ((int) dataSnapshot.getChildrenCount() != 0) {
                        Person newPerson = dataSnapshot.getValue(Person.class);
                        if (newPerson != null) {
                            Connected = newPerson.Connected;
                            Connection = newPerson.Connection;
                            Water1 = newPerson.Water;
                            GenderInt = newPerson.GenderId;
                            BMI = newPerson.BMI;
                            Kcal2 = newPerson.KcalTraining;
                            Kcal1 = newPerson.KcalNormal;
                            Training1 = newPerson.Training;
                            Diet1 = newPerson.Diet;
                            Gender = newPerson.Gender;
                            Age = newPerson.Age;
                            Weight = newPerson.Weight;
                            Height = newPerson.Height;
                            newDay = newPerson.Day;
                            newWeight = newPerson.NewWeight;
                            NewWeightBoolean = newPerson.NewWeightBoolean;
                            dataVals = newPerson.dataVals;
                            WaterMax = newPerson.WaterMax;

                            waterProgress();

                            waterText = findViewById(R.id.waterText);
                            waterText.setText(getString(R.string.drinked_format, getString(R.string.drinked), Water1, WaterMax));
                        }

                    } else {
                        Toast.makeText(WaterActivity.this, getString(R.string.db_problem), Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        } catch (Exception e) {
            Toast.makeText(WaterActivity.this, getString(R.string.db_error), Toast.LENGTH_SHORT).show();
        }
    }

    private void waterProgress () {
        waterProgress = findViewById(R.id.water_progress);
        if (Water1 >= WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water4);
        }
        else if (Water1 >= (7.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water3_5);
        }
        else if (Water1 >= (6.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water3);
        }
        else if (Water1 >= (5.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water2_5);
        }
        else if (Water1 >= (4.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water2);
        }
         else if (Water1 >= (3.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water1_5);

        }
        else if (Water1 >= (2.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water1);
        }
        else if (Water1 >= (1.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water0_5);
        }
        else if (Water1 < (1.0 / 8.0) * WaterMax)
        {
            waterProgress.setBackgroundResource(R.drawable.water0);
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        MediaPlayer clickAlert =MediaPlayer.create(WaterActivity.this, R.raw.click);
        if (clickAlert != null) clickAlert.start();
    }
}
