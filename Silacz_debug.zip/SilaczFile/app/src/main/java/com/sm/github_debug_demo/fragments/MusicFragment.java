package com.sm.github_debug_demo.fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.service.UpdateHpService;

import java.util.ArrayList;
import java.util.Locale;

public class MusicFragment extends Fragment {

    private int countMusic = 0;
    private Button startMusicButton, pauseMusicbutotn, stopMusicButton;
    private TextView titleTextView, idTextView;
    private Handler handler;
    private Runnable runnable;
    private TextView textViewTime, textViewDuration;
    private SeekBar timeBar;

    private ArrayList<String> playlistUris = new ArrayList<>();
    private ArrayList<String> playlistTitles = new ArrayList<>();

    // Odbiornik powiadomień o zmianie piosenki w serwisie
    private final BroadcastReceiver songChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (UpdateHpService.ACTION_SONG_CHANGED.equals(intent.getAction())) {
                countMusic = UpdateHpService.songId;
                updateDisplay();
            }
        }
    };

    private final ActivityResultLauncher<Intent> pickMusicLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();

                    if (data.getClipData() != null) {
                        ClipData clipData = data.getClipData();
                        for (int i = 0; i < clipData.getItemCount(); i++) {
                            Uri uri = clipData.getItemAt(i).getUri();
                            addSongToQueue(uri);
                        }
                    } else if (data.getData() != null) {
                        addSongToQueue(data.getData());
                    }

                    if (!UpdateHpService.running && !playlistUris.isEmpty()) {
                        playPlaylist(0);
                    } else {
                        Toast.makeText(getContext(), getString(R.string.added_to_queue), Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void addSongToQueue(Uri uri) {
        String uriString = uri.toString();
        String title = getFileName(uri);
        playlistUris.add(uriString);
        playlistTitles.add(title);
        
        // Synchronize with service if it's already running
        if (UpdateHpService.running) {
            UpdateHpService.playlistUris.add(uriString);
            UpdateHpService.playlistTitles.add(title);
        }
    }

    private boolean pendingPickAfterPermission = false;

    private final ActivityResultLauncher<String> requestPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestPermission(),
            isGranted -> {
                if (!isGranted) {
                    Toast.makeText(getContext(), getString(R.string.permission_denied_toast), Toast.LENGTH_SHORT).show();
                }
                // Niezależnie od wyniku (audio lub POST_NOTIFICATIONS) kontynuujemy flow:
                // jeśli audio jest przyznane, otwórz picker mimo odmowy notyfikacji.
                checkPermissionAndPickMusic();
            }
    );

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View layout = inflater.inflate(R.layout.fragment_music, container, false);

        // Inicjalizacja widoków
        Button nextMusicButton = layout.findViewById(R.id.buttonNext);
        Button previousMusicButton = layout.findViewById(R.id.buttonPrevious);
        startMusicButton = layout.findViewById(R.id.buttonStart);
        pauseMusicbutotn = layout.findViewById(R.id.buttonPause);
        stopMusicButton = layout.findViewById(R.id.buttonClose);
        ImageButton pickMusicButton = layout.findViewById(R.id.buttonPickMusic);
        titleTextView = layout.findViewById(R.id.titleTextView);
        idTextView = layout.findViewById(R.id.pisitionTextView);
        textViewTime = layout.findViewById(R.id.tvTime);
        textViewDuration = layout.findViewById(R.id.tvDuration);
        timeBar = layout.findViewById(R.id.timeBar);

        // Restore state if service is running
        if (UpdateHpService.running) {
            playlistUris = new ArrayList<>(UpdateHpService.playlistUris);
            playlistTitles = new ArrayList<>(UpdateHpService.playlistTitles);
            countMusic = UpdateHpService.songId;
            updateDisplay();
            
            startMusicButton.setVisibility(View.GONE);
            pauseMusicbutotn.setVisibility(View.VISIBLE);
            updatePauseButtonUI();
        } else {
            titleTextView.setText(getString(R.string.no_music_hint));
            idTextView.setText("");
        }

        pickMusicButton.setOnClickListener(v -> checkPermissionAndPickMusic());

        // Obsługa przycisków
        previousMusicButton.setOnClickListener(v -> {
            if (!playlistUris.isEmpty()) {
                countMusic = (countMusic <= 0) ? playlistUris.size() - 1 : countMusic - 1;
                playPlaylist(countMusic);
            }
        });

        nextMusicButton.setOnClickListener(v -> {
            if (!playlistUris.isEmpty()) {
                countMusic = (countMusic + 1) % playlistUris.size();
                playPlaylist(countMusic);
            }
        });

        startMusicButton.setOnClickListener(v -> {
            if (playlistUris.isEmpty()) checkPermissionAndPickMusic();
            else playPlaylist(countMusic);
        });

        pauseMusicbutotn.setOnClickListener(v -> {
            UpdateHpService.isPaused = !UpdateHpService.isPaused;
            updatePauseButtonUI();
        });

        stopMusicButton.setOnClickListener(v -> {
            stopMyService();
            playlistUris.clear();
            playlistTitles.clear();
            UpdateHpService.isPaused = false;
            titleTextView.setText(getString(R.string.queue_cleared));
            idTextView.setText("");
            pauseMusicbutotn.setVisibility(View.GONE);
            startMusicButton.setVisibility(View.VISIBLE);
        });

        setupButtonEffects(previousMusicButton, nextMusicButton, startMusicButton, pauseMusicbutotn, stopMusicButton);
        runLooper();
        return layout;
    }

    private void updatePauseButtonUI() {
        pauseMusicbutotn.setBackgroundResource(UpdateHpService.isPaused ? R.drawable.button_pause_1 : R.drawable.music_pause);
    }

    private boolean notificationPermissionRequested = false;

    private void checkPermissionAndPickMusic() {
        // 1. Sprawdź uprawnienia do audio
        String audioPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ?
                Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;

        boolean hasAudioPermission = ContextCompat.checkSelfPermission(requireContext(), audioPermission) == PackageManager.PERMISSION_GRANTED;

        if (!hasAudioPermission) {
            requestPermissionLauncher.launch(audioPermission);
            return;
        }

        // 2. Sprawdź uprawnienia do powiadomień (wymagane od Androida 13 dla Foreground Service).
        // Pytamy o nie tylko raz w ramach tej akcji – jeśli użytkownik odmówi, i tak otwieramy picker.
        boolean hasNotificationPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;

        if (!hasNotificationPermission && !notificationPermissionRequested) {
            notificationPermissionRequested = true;
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            return;
        }

        openMusicPicker();
    }

    private void openMusicPicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        pickMusicLauncher.launch(Intent.createChooser(intent, getString(R.string.select_music_to_queue)));
    }

    private void playPlaylist(int index) {
        countMusic = index;
        Intent serviceIntent = new Intent(getContext(), UpdateHpService.class);
        serviceIntent.putStringArrayListExtra(UpdateHpService.EXTRA_PLAYLIST_URIS, playlistUris);
        serviceIntent.putStringArrayListExtra(UpdateHpService.EXTRA_PLAYLIST_TITLES, playlistTitles);
        serviceIntent.putExtra(UpdateHpService.EXTRA_SONG_INDEX, countMusic);
        requireActivity().startService(serviceIntent);
        
        startMusicButton.setVisibility(View.GONE);
        pauseMusicbutotn.setVisibility(View.VISIBLE);
        UpdateHpService.isPaused = false;
        updatePauseButtonUI();
        updateDisplay();
    }

    private void updateDisplay() {
        if (!playlistTitles.isEmpty() && countMusic < playlistTitles.size()) {
            idTextView.setText(String.format(Locale.getDefault(), getString(R.string.music_id_format), countMusic + 1));
            titleTextView.setText(playlistTitles.get(countMusic));
            titleTextView.setSelected(true);
        }
    }

    @SuppressLint("Range")
    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = requireContext().getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    result = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            }
        }
        if (result == null) {
            result = uri.getPath();
            if (result != null) {
                int cut = result.lastIndexOf('/');
                if (cut != -1) result = result.substring(cut + 1);
            }
        }
        return result;
    }

    private void runLooper() {
        handler = new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                if (UpdateHpService.running && UpdateHpService.musicPlayer != null) {
                    try {
                        int current = UpdateHpService.musicPlayer.getCurrentPosition();
                        int duration = UpdateHpService.musicPlayer.getDuration();
                        textViewTime.setText(milisecondsToString(current));
                        textViewDuration.setText(milisecondsToString(duration));
                        timeBar.setMax(duration);
                        timeBar.setProgress(current);
                    } catch (Exception ignored) {}
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(runnable);
        
        timeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && UpdateHpService.running && UpdateHpService.musicPlayer != null) {
                    UpdateHpService.musicPlayer.seekTo(progress);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    public String milisecondsToString(int time) {
        return String.format(Locale.getDefault(), getString(R.string.music_time_format), time / 60000, (time % 60000) / 1000);
    }

    private void stopMyService() {
        requireActivity().stopService(new Intent(getContext(), UpdateHpService.class));
    }

    @Override
    public void onStart() {
        super.onStart();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requireActivity().registerReceiver(songChangeReceiver, new IntentFilter(UpdateHpService.ACTION_SONG_CHANGED), Context.RECEIVER_EXPORTED);
        } else {
            requireActivity().registerReceiver(songChangeReceiver, new IntentFilter(UpdateHpService.ACTION_SONG_CHANGED));
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        requireActivity().unregisterReceiver(songChangeReceiver);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupButtonEffects(View... buttons) {
        for (View b : buttons) {
            b.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.7f);
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.setAlpha(1.0f);
                }
                return false;
            });
        }
    }
}
