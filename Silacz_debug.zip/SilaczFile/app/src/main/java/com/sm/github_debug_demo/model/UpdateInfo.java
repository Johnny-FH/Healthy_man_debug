package com.sm.github_debug_demo.model;

/**
 * Created by Thor Odynson on 17.02.2021.
 */
public class UpdateInfo {
    public String updateInfo;

    public UpdateInfo() {
    }

    public UpdateInfo(String updateInfo) {
        this.updateInfo = updateInfo;
    }
}
