package com.sm.github_debug_demo.fragments;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sm.github_debug_demo.R;
import com.sm.github_debug_demo.activity.TrainingActivity;
import com.sm.github_debug_demo.adapters.CaptionedImagesAdapter2;


public class TrainingListFragment extends Fragment {

    static final int size = 30;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        RecyclerView trainingListRecycler = (RecyclerView) inflater.inflate(R.layout.fragment_training_list, container, false);



        String[] stringDay = new String[size];
        for (int i = 0; i < stringDay.length; i++)
        {
            stringDay[i] = getResources().getString(R.string.day) + " "+ (i+1);
        }


        CaptionedImagesAdapter2 adapter = new CaptionedImagesAdapter2(stringDay);
        trainingListRecycler.setAdapter(adapter);

        GridLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);
        trainingListRecycler.setLayoutManager(layoutManager);
        adapter.setListener(position -> {
            MediaPlayer clickAlert =MediaPlayer.create(getContext(), R.raw.click);
            clickAlert.start();
            Intent intent = new Intent(getActivity(), TrainingActivity.class);
            intent.putExtra(TrainingActivity.EXTRA_TRAINING_ID, position);
            requireActivity().startActivity(intent);
        });

        return trainingListRecycler;

    }
}