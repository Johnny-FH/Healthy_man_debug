package com.sm.github_debug_demo.adapters;


import android.view.LayoutInflater;

import android.view.ViewGroup;

import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.sm.github_debug_demo.R;


public class CaptionedImagesAdapter2 extends RecyclerView.Adapter<CaptionedImagesAdapter2.ViewHolder> {



    private Listener listener;
    private final String[] stringDay;
    public interface Listener
    {
        void onClick(int position);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public CaptionedImagesAdapter2(  String[] stringDay) {

        this.stringDay = stringDay;
    }

    @NonNull
    @Override
    public CaptionedImagesAdapter2.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        CardView cv = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.card_captioned_image2, parent, false);
        return new ViewHolder(cv);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder,  final int position) {
        final CardView cardView = holder.cardView;

        TextView textView = cardView.findViewById(R.id.day_text);
        textView.setText(stringDay[position]);




        cardView.setOnClickListener(v -> {
            if (listener != null)
            {
                listener.onClick(position);
            }
        });



    }

    @Override
    public int getItemCount() {
        return stringDay.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder  {
        private final CardView cardView;

        public ViewHolder(CardView v)
        {
            super(v);
            cardView = v;
        }

    }
}