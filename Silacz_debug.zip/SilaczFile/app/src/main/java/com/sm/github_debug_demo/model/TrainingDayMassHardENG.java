package com.sm.github_debug_demo.model;

public class TrainingDayMassHardENG {

    private String training1;
    private String training2;
    private String training3;
    private String training4;
    private String training5;
    private String training6;
    private String training7;
    private String training8;
    private String training9;
    private String training10;
    private String training11;

    public static final TrainingDayMassHardENG[] trainingDayMassHard =
            {

                    new TrainingDayMassHardENG("Crunches x25",

                            "Isometric abdominal clash 25 seconds \n \n Break 30 seconds",

                            "Alternating leg lifting x7 per side",

                            "Bike 45 seconds",

                            "Double crunch x20 \n \n 30 seconds break",

                            "Mountain climber 45 seconds",

                            "Reverse crunches x20",

                            "Plank 45 seconds \n \n Break 30 seconds",

                            "High stepping 45 seconds",

                            "Isometric Abdominal Clamp 25 Seconds"),
                    new TrainingDayMassHardENG("Squats x25",

                            "Chair against the wall 35 seconds 2 series",

                            "Lunges x25 \n \n Break 30 seconds",

                            "Low jumps x25",

                            "Sumo squats x25",

                            "Squats with jump x25 \n \n Break 30 seconds",

                            "Pulse squats x25",

                            "Plank with leg lift 35 seconds",

                            "Side Leg Raise 15 Times Per Side"),
                    new TrainingDayMassHardENG(
                            "Ordinary pumps x25",

                            "Rompers x25",

                            "Circulation of arms 20 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 35 seconds",

                            "Shooting pumps x15",

                            "Push-ups with a stop at the bottom after 3 seconds x10 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x10",

                            "Diamond pumps x12",

                            "Dips (on chairs) x20"),
                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("Jumping in the place of 40 seconds",

                            "Rompers x25",

                            "Sprint in 30 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x15",

                            "Skiping A 35 seconds",

                            "Skiping C 35 seconds \n \n Break 30 seconds",

                            "Mountain climber vigorously 20 seconds",

                            "Feet together, jump forward and backward x20",

                            "Sprint in 30 seconds"),

                    new TrainingDayMassHardENG(
                            "Sumo squats x25",

                            "Raising the hips x25  \n \n Pause 30 seconds",

                            "Side lunges x15 (one side)",

                            "Back Kick on All Fours x20 right side",

                            "Backwards kick on all fours x20 left side \n \n Break 30 seconds",

                            "Raise the legs while lying on the side x15 right side",

                            "Raising the legs while lying on the side x15 left side"),
                    new TrainingDayMassHardENG(
                            "We lean forward and try to touch the ground (deepened) x15",

                            "Hurdle sitting with straight right leg 40 seconds",

                            "Hurdle sitting with straight left leg 40 seconds",

                            "Sit down every 40 seconds \n \n  Break 30 seconds",

                            "Butterfly 35 seconds",

                            "Slowly shifting weight from left to right x8",

                            "Pulling the right knee to the chest 20 seconds",

                            "Pulling the left knee to the chest 20 seconds \n \n 30 seconds break",

                            "Analogous pull of the heel to the buttock (right leg) x8",

                            "Analogous pull of the heel to the buttock (left leg) x8",

                            "Loose jumps for muscle relaxation x15"),
                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("X30 crunches",

                            "Isometric abdominal clash 30 seconds \n \n Break 30 seconds",

                            "Alternating leg lifting x10 per side",

                            "Bicycle 50 seconds",

                            "Double crunch x25 \n \n 30 seconds break",

                            "Mountain climber 50 seconds",

                            "Reverse crunches x25",

                            "Plank 50 seconds \n \n Break 30 seconds",

                            "High stepping 50 seconds",

                            "Isometric Abdominal Clamp 30 Seconds"
                    ),
                    new TrainingDayMassHardENG("Squats x30",

                            "Chair against the wall 40 seconds 2 series",

                            "Lunge x30 \n \n Break 30 seconds",

                            "Low jumps x30",

                            "Sumo squats x30",

                            "Squats with jump x30 \n \n Break 30 seconds",

                            "Pulse squats x30",

                            "Plank with lifting legs 40 seconds",

                            "Side Leg Raises 20 Times Per Side"),

                    new TrainingDayMassHardENG("Ordinary pumps x30",

                            "Rompers x30",

                            "Circulation of arms 20 seconds \n \n Break 30 seconds",

                            "Plank with alternating arms forward 40 seconds",

                            "X20 shooting pumps",

                            "Push-ups with a stop at the bottom after 3 seconds x15 \n \n Break 30 seconds",

                            "Push-ups on a platform (e.g. legs on the bed) x15",

                            "Diamond pumps x15",

                            "Dips (on chairs) x25"),
                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("Jumping 45 seconds",

                            "Rompers x30",

                            "Sprint in place 35 seconds \n \n Break 30 seconds",

                            "Jumps (2 lower then 1 higher) x20",

                            "Skiping A 40 seconds",

                            "Skiping C 40 seconds \n \n Break 30 seconds",

                            "Mountain climber vigorously 25 seconds",

                            "Feet together, jump forward and backward x25",

                            "Sprint in 35 seconds"),
                    new TrainingDayMassHardENG("Sumo squats x30",

                            "Raising the hips x30 \n \n Pause 30 seconds",

                            "Side lunges x20 (one side)",

                            "Back Kick on All Fours x25 right side",

                            "Backward kick on all fours x25 left side \n \n Break 30 seconds",

                            "Raising the legs while lying on the side x20 right side",

                            "Raising the legs while lying on the side x20 left side"),
                    new TrainingDayMassHardENG("When we stride, we lean down and try to touch the ground (deepened) x20",

                            "Hurdle sitting with straight right leg 45 seconds",

                            "Hurdle sitting with straight left leg 45 seconds",

                            "Sit down every 45 seconds \n \n Break 30 seconds",

                            "Butterfly 40 seconds",

                            "Slowly shifting weight from left to right x12",

                            "Pulling the right knee to the chest 25 seconds",

                            "Pulling the left knee to the chest 25 seconds \n \n Break 30 seconds",

                            "Analogous pull of the heel to the buttock (right leg) x12",

                            "Analogous pull of the heel to the buttock (left leg) x12",

                            "Loose jumps for muscle relaxation x20"),

                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("X35 crunches",
                            "Isometric abdominal clash 35 seconds \n \n Break 30 seconds",
                            "Alternating leg lifting x15 per side",
                            "Bicycles 55 seconds",
                            "Double crunch x30 \n \n 30 seconds break",
                            "Mountain climber 55 seconds",
                            "Reverse crunches x30",
                            "Plank 55 seconds \n \n Break 30 seconds",
                            "High stepping 55 seconds",
                            "Isometric Abdominal Clamp 35 Seconds"),
                    new TrainingDayMassHardENG("Squats x35",
                            "Chair against the wall 45 seconds 2 series",
                            "Lunge x35 \n \n Break 30 seconds",
                            "Low jumps x35",
                            "Sumo squats x35",
                            "Squats with jump x35 \n \n Break 30 seconds",
                            "Pulse squats x35",
                            "Plank with leg lift 45 seconds",
                            "Side Leg Raise 25 Times Per Side"),
                    new TrainingDayMassHardENG("Ordinary pumps x35",
                            "Rompers x35",
                            "Circulation of arms 20 seconds \n  \n Break 30 seconds",
                            "Plank with alternating arms forward 45 seconds",
                            "X25 shooting pumps",
                            "Push-ups with a stop at the bottom after 3 seconds x20 \n \n Break 30 seconds",
                            "Push-ups on a platform (e.g. legs on the bed) x20",
                            "Diamond pumps x18",
                            "Dips (on chairs) x30"),
                    new TrainingDayMassHardENG("FREE DAY"),

                    new TrainingDayMassHardENG("Jumping in the place of 50 seconds",
                            "Rompers x35",
                            "Sprint in place 40 seconds \n \n Break 30 seconds",
                            "Jumps (2 lower then 1 higher) x25",
                            "Skiping A 45 seconds",
                            "Skiping C 45 seconds \n \n Break 30 seconds",
                            "Mountain climber vigorously 30 seconds",
                            "Feet together, jump forward and backward x30",
                            "Sprint in 40 Seconds"),
                    new TrainingDayMassHardENG("Sumo squats x35",
                            "Raising the hips x35 \n \n Pause 30 seconds",
                            "Side lunges x25 (one side)",
                            "Back Kick on All Fours x30 right side",
                            "Back Kicks x30 left side \n \n Break 30 seconds",
                            "Raising the legs while lying on the side x25 right side",
                            "Raising the legs while lying on the side x25 left side"),
                    new TrainingDayMassHardENG("We lean forward and try to touch the ground (deepened) x25",
                            "Hurdle sitting with straight right leg 50 seconds",
                            "Hurdle sitting with straight left leg 50 seconds",
                            "Sit down every 50 seconds \n \n Break 30 seconds",
                            "Butterfly 45 seconds",
                            "Slowly shifting weight from left to right x15",
                            "Pulling the right knee to the chest 30 seconds",
                            "Pulling the left knee to the chest 30 seconds \n \n Break 30 seconds",
                            "Analogous pull of the heel to the buttock (right leg) x15",
                            "Analogous heel pull to the buttock (left leg) x15",
                            "Loose jumps for muscle relaxation x25"),
                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("Crunches x40",
                            "Isometric abdominal clutch 40 seconds \n \n Break 30 seconds",
                            "Alternating leg lifting x18 per side",
                            "Bicycle 60 seconds",
                            "Double crunch x35 \n \n 30 seconds break",
                            "Mountain climber 60 seconds",
                            "Reverse crunches x35",
                            "Plank 60 seconds \n \n Break 30 seconds",
                            "High stepping 60 seconds",
                            "Isometric Abdominal Clamp 40 Seconds"),

                    new TrainingDayMassHardENG(
                            "Squats x40",
                            "Chair against the wall 50 seconds 2 series",
                            "Lunge x40 \n \n Break 30 seconds",
                            "Low jumps x40",
                            "Sumo squats x40",
                            "Squats with jump x40 \n \n Break 30 seconds",
                            "Pulse squats x40",
                            "Plank with lifting legs 50 seconds",
                            "Raising one leg on the side 30 times per side"),
                    new TrainingDayMassHardENG("Pompki zwykłe x40" ,
                            "Pajacyki x40" ,
                            "Krążenie ramion 20 sekund \n \n Przerwa 30 sekund" ,
                            "Plank z podnoszeniem naprzemiennym rąk do przodu 50 sekund" ,
                            "Pompki strzeleckie x30" ,
                            "Pompki z zatrzymaniem na dole po 3 sekundy x25 \n \n Przerwa 30 sekund" ,
                            "Pompki na podwyższeniu (np. nogi na łóżku) x25" ,
                            "Pompki diamentowe x21" ,
                            "Dipy (na krzesłach) x35"),
                    new TrainingDayMassHardENG("FREE DAY"),
                    new TrainingDayMassHardENG("Jumping in 55 seconds",
                            "Rompers x40",
                            "Sprint in place 45 seconds \n \n Break 30 seconds",
                            "Jumps (2 lower then 1 higher) x30",
                            "Skiping A 50 seconds",
                            "Skiping C 50 seconds \n \n Break 30 seconds",
                            "Mountain climber vigorously 35 seconds",
                            "Feet together, jump forward and backward x35",
                            "Sprint in place 45 seconds"),
                    new TrainingDayMassHardENG("Sumo squats x40",

                            "Raising the hips x40 \n \n Pause 30 seconds",
                            "Side lunges x35 (one side)",
                            "Back Kick on All Fours x35 right side",
                            "Backward kicking on all fours x35 left side \n \n Break 30 seconds",
                            "Raising the legs while lying on the side x30 right side",
                            "Raising the legs while lying on the side x30 left side")
            };

    public TrainingDayMassHardENG() {
    }

    public TrainingDayMassHardENG(String training1) {
        this.training1 = training1;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10, String training11) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;
        this.training11 = training11;
    }

    public TrainingDayMassHardENG(String training1, String training2, String training3, String training4, String training5, String training6, String training7, String training8, String training9, String training10) {
        this.training1 = training1;
        this.training2 = training2;
        this.training3 = training3;
        this.training4 = training4;
        this.training5 = training5;
        this.training6 = training6;
        this.training7 = training7;
        this.training8 = training8;
        this.training9 = training9;
        this.training10 = training10;


    } // cons

    public String getTraining1() {
        return training1;
    }

    public String getTraining2() {
        return training2;
    }

    public String getTraining3() {
        return training3;
    }

    public String getTraining4() {
        return training4;
    }

    public String getTraining5() {
        return training5;
    }

    public String getTraining6() {
        return training6;
    }

    public String getTraining7() {
        return training7;
    }

    public String getTraining8() {
        return training8;
    }

    public String getTraining9() {
        return training9;
    }

    public String getTraining10() {
        return training10;
    }

    public String getTraining11() {
        return training11;
    }

    public static TrainingDayMassHardENG[] getTrainingDayMassHard() {
        return trainingDayMassHard;
    } // gett
}
